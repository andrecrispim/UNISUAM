describe('unisuamApp', function () {
  var scope,
  controller,
  service;

  beforeEach(function () {
      module('unisuamApp', function($provide) {
        $provide.value('$log', {
          log: jasmine.createSpy('log')
        });
        $provide.value("$exceptionHandler", {
          exceptionHandler: jasmine.createSpy('exceptionHandler')
        });
      });
  });

  describe('reportCardController', function () {
      beforeEach(inject(function ($rootScope, $controller) {
          scope = $rootScope.$new();
          controller = $controller('reportCardController', {
              '$scope': scope
          });
      }));

      it('should ("reportCardController") not to be undefined', function(){
        expect(scope).not.toBeUndefined();
      });

      it('should (method "init") not to be undefined', function () {
          expect(scope.init).not.toBeUndefined();
      });
  });

  describe('reportCardService', function() {
    beforeEach(inject(function ($rootScope, _reportCardService_) {
      scope = $rootScope.$new();
      service = _reportCardService_;
    }));

    it('should have an getReportCard function', function () {
      expect(angular.isFunction(service.getReportCard)).toBe(true);
    });

  });

});