describe('unisuamApp', function () {
  var scope,
  controller;

  beforeEach(function () {
      module('unisuamApp', function($provide) {
        $provide.value('$log', {
          log: jasmine.createSpy('log')
        });
        $provide.value("$exceptionHandler", {
          exceptionHandler: jasmine.createSpy('exceptionHandler')
        });
      });
  });

  describe('chooseCourseController', function () {
      beforeEach(inject(function ($rootScope, $controller) {
          scope = $rootScope.$new();
          controller = $controller('chooseCourseController', {
              '$scope': scope
          });
      }));

      it('should ("chooseCourseController") not to be undefined', function(){
        expect(scope).not.toBeUndefined();
      });

      it('should (method "init") not to be undefined', function () {
          expect(scope.init).not.toBeUndefined();
      });

      it('should (method "getLocalStorageCourses") not to be undefined', function () {
          expect(scope.getLocalStorageCourses).not.toBeUndefined();
      });

      it('should (method "goToCourse") not to be undefined', function () {
          expect(scope.goToCourse).not.toBeUndefined();
      });
  });

});