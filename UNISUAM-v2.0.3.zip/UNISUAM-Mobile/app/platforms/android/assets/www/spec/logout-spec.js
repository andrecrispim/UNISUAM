describe('unisuamApp', function () {
  var scope,
  controller;

  beforeEach(function () {
      module('unisuamApp', function($provide) {
        $provide.value('$log', {
          log: jasmine.createSpy('log')
        });
        $provide.value("$exceptionHandler", {
          exceptionHandler: jasmine.createSpy('exceptionHandler')
        });
      });
  });

  describe('logouController', function () {
      beforeEach(inject(function ($rootScope, $controller) {
          scope = $rootScope.$new();
          controller = $controller('logoutController', {
              '$scope': scope
          });
      }));

      it('should ("logoutController") not to be undefined', function(){
        expect(scope).not.toBeUndefined();
      });

      it('should (method "logout") not to be undefined', function () {
          expect(scope.logout).not.toBeUndefined();
      });
  });
});