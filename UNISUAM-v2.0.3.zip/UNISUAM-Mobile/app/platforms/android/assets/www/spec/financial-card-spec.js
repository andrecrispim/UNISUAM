describe('unisuamApp', function () {
  var scope,
  controller;

  beforeEach(function () {
      module('unisuamApp', function($provide) {
        $provide.value('$log', {
          log: jasmine.createSpy('log')
        });
        $provide.value("$exceptionHandler", {
          exceptionHandler: jasmine.createSpy('exceptionHandler')
        });
      });
  });

  describe('financialCardController', function () {
      beforeEach(inject(function ($rootScope, $controller) {
          scope = $rootScope.$new();
          controller = $controller('financialCardController', {
              '$scope': scope
          });
      }));

      it('should ("financialCardController") not to be undefined', function(){
        expect(scope).not.toBeUndefined();
      });

      it('should (method "getData") not to be undefined', function () {
          expect(scope.getData).not.toBeUndefined();
      });
  });
});