describe('unisuamApp', function () {
  var scope,
  controller,
  service;

  beforeEach(function () {
      module('unisuamApp', function($provide) {
        $provide.value('$log', {
          log: jasmine.createSpy('log')
        });
        $provide.value("$exceptionHandler", {
          exceptionHandler: jasmine.createSpy('exceptionHandler')
        });
      });
  });

  describe('loginController', function () {
      beforeEach(inject(function ($rootScope, $controller) {
          scope = $rootScope.$new();
          controller = $controller('loginController', {
              '$scope': scope
          });
          $document = angular.element(document); // This is exactly what Angular does
          $document.find('body').append('<div id="loading-modal"></div>');
          scope.init();
      }));

      it('should ("loginController") not to be undefined', function(){
        expect(scope).not.toBeUndefined();
      });

      it('should (method "doLogin") not to be undefined', function () {
          expect(scope.doLogin).not.toBeUndefined();
      });

      it('should userLogin parameter size minor to 20',function(){
          scope.userLogin = "MockUserLogin";
          scope.userPass = "MockPass";
          scope.doLogin();
          expect(scope.userLogin.length).toBeLessThan(20);
      });

      it('should userPass parameter size minor to 21',function(){
          scope.userLogin = "MockUserLogin";
          scope.userPass = "MockPass";
          scope.doLogin();
          expect(scope.userPass.length).toBeLessThan(21);
      });
  });

  describe('loginService', function () {
    beforeEach(inject(function ($rootScope, _loginService_) {
      scope = $rootScope.$new();
      service = _loginService_;
    }));

    it('should have an undergraduateVerifyLogin function', function () {
      expect(angular.isFunction(service.undergraduateVerifyLogin)).toBe(true);
    });

  });


});