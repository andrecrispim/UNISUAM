"use strict";

/**
 * Controlador da tela do quadro de horário da pós-graduação
 *
 * @class
 * @name graduationSchedulesController
 * 
 * @param {Object} $scope Escopo
 * @param {Object} $timeout Serviço de timeout
 * @param {schedulesService} schedulesService Serviço para busca o quadro de horário
 */
function graduationSchedulesController($scope, $timeout, schedulesService) {
    var UPCOMING_CLASS_INDEX = -1;

    /**
     * Dados do quadro de horário
     * 
     * @type {Object}
     */
    $scope.schedules = null;
    
    /**
     * Dados de aulas futuras
     * 
     * @type {Array.<Object>}
     */
    $scope.upcomingClasses = null;
    
    /**
     * Indica se existem aulas futuras
     * 
     * @type {boolean}
     */
    $scope.hasUpcomingClasses = false;
    
    /**
     * Índice selecionado
     * 
     * @type {number}
     */
    $scope.selectedIndex = null;
    
    /**
     * Horários da disciplina atual
     * 
     * @type {Array.<Object>}
     */
    $scope.disciplineSchedules = [];

    /**
     * Trata o evento disparado quando um repeater termina
     *
     * @param {Object} ngRepeatFinishedEvent Evento
     */
    $scope.$on('ngRepeatFinished', function (ngRepeatFinishedEvent) {
        $timeout(function () {
            $scope.refresh();
        }, 50);
    });

    /**
     * Inicializa a tela
     *
     * @memberof schedulesController
     * @function
     */
    $scope.init = function () {
        schedulesService.getSchedules().then(handleSuccess, function (result) {
            $scope.handleError(result, $scope.dialog);
        });
    };

    /**
     * Abre ou fecha um painel
     *
     * @memberof schedulesController
     * @function
     * 
     * @param {number} index Índice da disciplina
     */
    $scope.togglePanel = function (index) {
        $scope.selectedIndex = $scope.selectedIndex == null || $scope.selectedIndex != index ? index : null;

        // carrega os horários da disciplina atual
        if ($scope.selectedIndex != null && $scope.selectedIndex >= 0 && $scope.disciplineSchedules[index] == null) {
            var adjustedDisciplineSchedules = null;
            var label = $scope.schedules[index].disciplina.label;
            var discipline = $scope.schedules[index].disciplina;

            if (discipline.horario != null) {
                adjustedDisciplineSchedules = [];

                for (var i = 0, len = discipline.horario.length; i < len; i++) {
                    var disciplineSchedule = discipline.horario[i];

                    // concatena os nomes
                    var teachersNames = [];
                    var separator = ", ";
                    var teachers = disciplineSchedule.professores;
                    if (teachers != null && teachers.length > 0) {
                        for (var j = 0, lenTeachers = teachers.length; j < lenTeachers; j++) {
                            teachersNames.push(teachers[j].nome);
                        }
                    }

                    adjustedDisciplineSchedules.push({
                        disciplina_label: label,
                        professores: teachersNames.join(separator),
                        data: disciplineSchedule.data,
                        diasemana: disciplineSchedule.dia,
                        horainicio: disciplineSchedule.horainicio_formatada,
                        horafim: disciplineSchedule.horafim_formatada,
                        sala: disciplineSchedule.sala,
                        bloco: disciplineSchedule.bloco,
                        unidade: disciplineSchedule.unidade
                    });
                }
            }

            $scope.disciplineSchedules[index] = adjustedDisciplineSchedules;
        }

        // é necessário atualizar a tela senão a página terá uma altura menor do que a tela
        $timeout(function () {
            $scope.refresh();
        }, 50);
    };

    /**
     * Verifica se um horário é antigo, ele é antigo se for anterior ao dia atual
     *
     * @memberof graduationSchedulesController
     * @function
     * 
     * @param {string} scheduleDate Data
     * 
     * @return {boolean} True se for antigo, false caso contrário
     */
    $scope.isOldSchedule = function (scheduleDate) {
        // retorna falso se a data for nula ou inválida
        if (scheduleDate == null) {
            return false;
        }

        var dateParts = scheduleDate.split('/');

        if (dateParts.length != 3) {
            return false;
        }

        today = new Date();
        today.setHours(0, 0, 0, 0);
        return new Date(dateParts[2], dateParts[1] - 1, dateParts[0]) <= today;
    };

    /**
     * Método chamado quando a busca do quadro de horário terminar com sucesso
     *
     * @memberof undergraduateSchedulesController
     * @private
     * @function
     * @method success
     * 
     * @param {Object} result Resultado, inclui a configuração da requisição, cabeçalho e status
     */
    function handleSuccess(result) {
        var hasSchedules = false;
        var hasError = result.data.errors != null && result.data.errors.length > 0;

        if (result.data.data != null) {
            $scope.upcomingClasses = adjustUpcomingClasses(result.data.data.proximasAulas);
            $scope.hasUpcomingClasses = $scope.upcomingClasses != null && $scope.upcomingClasses.length > 0;
            $scope.schedules = result.data.data.quadroHorario;
            hasSchedules = $scope.schedules != null && $scope.schedules.length > 0;

            if ($scope.hasUpcomingClasses) {
                $scope.selectedIndex = UPCOMING_CLASS_INDEX;
            }
        }

        // limpa as mensagens
        $scope.messages.length = 0;

        if (hasError) {
            for (var i = 0, len = result.data.errors.length; i < len; i++) {
                $scope.messages.push(result.data.errors[i].message);
            }
        } else if (!$scope.hasUpcomingClasses && !hasSchedules) {
            $scope.messages.push("Não há dados cadastrados até o momento.");
        }

        $scope.hideLoading();
    }

    /**
     * Ajusta a informação das aulas futuras 
     *
     * @memberof undergraduateSchedulesController
     * @function
     * 
     * @param {Array.<Object>} upcomingClasses Aulas futuras
     * 
     * @returns {Object} Informações ajustadas
     */
    function adjustUpcomingClasses(upcomingClasses) {
        if (upcomingClasses == null || upcomingClasses.length == 0) {
            return [];
        }

        var adjustedUpcomingClasses = [];

        for (var i = 0, len = upcomingClasses.length; i < len; i++) {
            var upcomingClass = upcomingClasses[i];

            adjustedUpcomingClasses.push({
                disciplina_nome: upcomingClass.disciplina_nome,
                professores: upcomingClass.professores,
                data: upcomingClass.quadrohorario_data,
                diasemana: upcomingClass.quadrohorario_diasemana,
                horainicio: upcomingClass.quadrohorario_horainicio_formatada,
                horafim: upcomingClass.quadrohorario_horafim_formatada,
                sala: upcomingClass.quadrohorario_sala,
                bloco: upcomingClass.quadrohorario_bloco,
                unidade: upcomingClass.quadrohorario_unidade
            });
        }

        return adjustedUpcomingClasses;
    }
}