// módulo de log
var logger = angular.module('logger', ['config']);

/**
 * Serviço de log
 * 
 * @class
 * @name loggerService
 * 
 * @param {CONFIG} CONFIG Configuração
 */
logger.factory('loggerService', function(CONFIG) {
  var logService = {};
  var ERROR = 0;
  var WARN = 1;
  var INFO = 2;
  var DEBUG = 3;
  var _$log = null;
  var platform = null;

  // inicia o LogEntries {@link http://logentries.com/}
  LE.init(CONFIG.LOG.TOKEN);
  
  function getPlatformMessage(message) {
	  if (platform == null) {
		  platform = window.device.platform + "(" + window.device.version + "): ";
	  }
	  
	  return platform + message;
  }
  
  /**
   * Se estiver habilitado o log para VISUAL_STUDIO loga em debug 
   * senão loga normalmente usando o método recebido como parâmetro
   */
  function localLog(message, log) {
	  if (CONFIG.LOG.VISUAL_STUDIO){
		  _$log.debug(message);
	  } else {
		  log(message);
	  }
  }

  /**
   * Inicializa os logs guardando o serviço de log padrão
   */
  logService.init = function($log) {
    _$log = {
        log: $log.log,
        info: $log.info,
        warn: $log.warn,
        debug: $log.debug,
        error: $log.error
    };
  };
    
  /**
   * Loga uma mensagem
   *
   * @memberof logService
   * @function
   * 
   * @param {string} message Mensagem
   */
  logService.log = function(message) {
	logService.debug(message);    
  };

  /**
   * Log a debug message string
   *
   * @memberof logService
   * @function
   * 
   * @param {string} message Mensagem
   */
  logService.debug = function(message) {
    if (CONFIG.LOG.LEVEL == DEBUG) {
      if (CONFIG.LOG.REMOTE_LOG_LEVEL == DEBUG) {
          LE.log(getPlatformMessage(message));
      }

      _$log.debug(message);
    }
  };

  /**
   * Loga uma mensagem de informação
   *
   * @memberof logService
   * @function
   * 
   * @param {string} message Mensagem
   */
  logService.info = function(message) {
    if (CONFIG.LOG.LEVEL >= INFO) {
      if (CONFIG.LOG.REMOTE_LOG_LEVEL >= INFO) {
          LE.info(getPlatformMessage(message));
      }

      localLog(message, _$log.info);
    }
  };

  /**
   * Loga uma mensagem de alerta
   *
   * @memberof logService
   * @function
   * 
   * @param {string} message Mensagem
   */
  logService.warn = function(message) {
    if (CONFIG.LOG.LEVEL >= WARN) {
      if (CONFIG.LOG.REMOTE_LOG_LEVEL >= WARN) {
    	  LE.warn(getPlatformMessage(message));
      }

      localLog(message, _$log.warn);
    }
  };

  /**
   * Loga uma mensagem de erro
   *
   * @memberof logService
   * @function
   * 
   * @param {string} message Mensagem
   */
  logService.error = function(message) {
    if (CONFIG.LOG.LEVEL >= ERROR) {
      if (CONFIG.LOG.REMOTE_LOG_LEVEL >= ERROR) {
          LE.error(getPlatformMessage(message));
      }

      localLog(message, _$log.error);
    }
  };

  // apenas necessário para suportar o angular-mocks
  logService.logs = [];

  return logService;
});

/**
 * Configura o provedor de log para que utiliza essa classe
 */
logger.config(function($provide) {
  $provide.decorator('$log', function($delegate, loggerService) {
      loggerService.init($delegate);
      return loggerService;
  });

  $provide.decorator("$exceptionHandler", function($delegate, $injector, loggerService){
      return function(exception, cause){
          loggerService.error("ANGULAR ERROR: " + exception + " cause: " + cause);
          $delegate(exception, cause);
      };
  });
});
