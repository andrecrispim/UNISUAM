"use strict";

/**
 * Controlador da tela de finanças da graduação
 *
 * @class
 * @name undergraduateFinancialCardController
 * 
 * @param {Object} $scope Escopo
 * @param {Object} $log Log
 * @param {Object} $filter Filtro
 * @param {financialCardService} financialCardService Serviço para busca de finanças
 */
function undergraduateFinancialCardController($scope, $log, $filter, financialCardService) {

	/**
     * Inicializa a tela
     *
     * @memberof undergraduateFinancialCardController
     * @function
     */
    $scope.init = function () {
        financialCardService.getFinancialData().then(handleRequest.success, function (result) {
        	$scope.handleError(result, $scope.dialog);
        });
    };

    /**
     * Trata o resultado da busca dos dados no backend quando for feita com sucesso
     * 
     * @memberof undergraduateFinancialCardController
     * @private
     * @function
     * @method success
     */
    var handleRequest = function () {
        function treatError(thisData) {
            if (thisData.data.errors.length > 0) {
                $scope.errors = true;
                $scope.errorMessage = {
                    "message": thisData.data.errors[0].message
                };

                $scope.handleError($scope.errorMessage, $scope.dialog);
                return $scope.errors;
            }
        }

        function success(thisData) {
        	
            if (thisData == null || thisData.data == null || thisData.data.errors == null && thisData.data.data == null) {
                $log.error("O servidor não retornou dados válidos ao buscar por ficha financeira.");
                $scope.hideLoading();
                $scope.dialog.error("Não foi possível buscar a ficha financeira, tente novamente.");
                return;
            }

            if (!treatError(thisData)) {
            	
                angular.forEach(thisData.data.data, function (valuePri, keyPri) {

                    $scope.errors = thisData.data.errors;

                    if (valuePri.title == 'Graduação') {

                        // Order
                        var result0Values = [];
                        Object.keys(thisData.data.data[keyPri].data).forEach(function (key) {
                            result0Values.push({key: key, value: thisData.data.data[keyPri].data[key]});
                        });

                        $scope.result0Columns = thisData.data.data[keyPri].columns;
                        $scope.result0Values = result0Values;
                    }

                    if (valuePri.title == 'Extensão') {

                        // Order
                        var result1Values = [];
                        Object.keys(thisData.data.data[keyPri].data).forEach(function (key) {
                            result1Values.push({key: key, value: thisData.data.data[keyPri].data[key]});
                        });

                        $scope.result1Columns = thisData.data.data[keyPri].columns;
                        $scope.result1Values = result1Values;
                    }

                    if (valuePri.title == 'Biblioteca') {

                        if (thisData.data.data[keyPri].data) {

                            $scope.result2Columns = thisData.data.data[keyPri].columns;
                            $scope.result2Values = thisData.data.data[keyPri].data;
                        }
                    }

                    if (valuePri.title == 'Protocolo') {

                        if (thisData.data.data[keyPri].data) {

                            $scope.result3Columns = thisData.data.data[keyPri].columns;
                            $scope.result3Values = thisData.data.data[keyPri].data;
                        }
                    }

                    if (valuePri.title == 'Cheque') {

                        if (thisData.data.data[keyPri].data) {

                            $scope.result4Columns = thisData.data.data[keyPri].columns;
                            $scope.result4Values = thisData.data.data[keyPri].data;
                        }
                    }

                    if (valuePri.title == 'Promissória') {

                        if (thisData.data.data[keyPri].data) {

                            $scope.result5Columns = thisData.data.data[keyPri].columns;
                            $scope.result5Values = thisData.data.data[keyPri].data;
                        }
                    }
                });
            }
        }

        return {
            success: function (result) {
                success(result);
                $scope.hideLoading();
            }
        };
    }();
}