/**
 * Serviço responsável por buscar o menu no servidor remoto 
 * e manter as configurações das páginas
 *
 * @class
 * @name pagesService
 * 
 * @param {Object} $http Serviço HTTP
 * @param {Object} $q Promessa
 * @param {Object} $log Log
 * @param {localStorageService} localStorageService Serviço de armazenamento local
 * @param {CONFIG} CONFIG Configuração
 */
app.service('pagesService', ['$http', '$q', '$log', 'localStorageService', 'CONFIG',
                                  function ($http, $q, $log, localStorageService, CONFIG) {

	var LAST_MENU = "lastMenu";
	var STUDENT_COURSE_LEVEL_KEY = "studentCourseLevel";
	var UNDERGRADUATE = "GRADUACAO";
	
	var _this = this;
	
	/**
	 * Páginas e seus respectivos identificadores
	 */
	var PAGES = { 
		NEWS : 1,
		FINANCIAL : 2,
		EXAMS : 3,
		REPORT_CARD : 4,
		SCHEDULES : 5,
		INDICATIONS : 6,
		CONFIGURATION : 7,
		LOGOUT : 8
	};
	    
	/**
	 * Dados das páginas.
	 * 
	 * A posição no array é igual ao identificador da página - 1.
	 */
    var PAGES_DATA = [
        {name: "Notícias",      path: "/news",           className: "menu-news",          config: true},
        {name: "Financeiro",    path: "/financial-card", className: "menu-financial",     config: true},
        {name: "Provas", 	    path: "/exams",          className: "menu-exams",         config: true},        
        {name: "Boletim",       path: "/report-card",    className: "menu-report-card",   config: true},
        {name: "Horários",      path: "/schedules",      className: "menu-schedules",     config: true},
        {name: "Indicações",    path: "/indications",    className: "menu-indications",   config: true},        
        {name: "Configurações", path: "/configuration",  className: "menu-configuration", config: false},
        {name: "Sair",          path: "/logout",         className: "menu-logout",        config: false}
    ];
		
	var menu = null;
	var deferredResponse = null
	
	/**
     * Indica se há um menu carregado
     *
     * @memberof pagesService
     * @function
     * 
     * @return boolean True se um menu está carregado, false caso contrário
	 */
	this.hasMenu = function () {
		return menu != null;
	};
	
	/**
	 * Busca as páginas disponíveis para configuração da página inicial.
	 * 
	 * O menu já deve ter sido buscado no servidor para que retorne as páginas correspondentes.
	 * 
     * @memberof pagesService
     * @function
     * 
     * @return {Array<Object>} Páginas
	 */
	this.getPagesForConfiguration = function() {
		var pages = [];
		var currentMenu = _this.getCourseMenu();
				
		for (var i = 0, size = PAGES_DATA.length; i < size; i++) {
			var page = PAGES_DATA[i];
			var menuId = i + 1;
						
			if (page.config && currentMenu.indexOf(menuId) >= 0) {
				pages.push(page);
			}
		}
		
		return pages;
	};
	
	/**
	 * Busca uma página pelo seu nome
	 * 
	 * O menu já deve ter sido buscado no servidor para que retorne as páginas correspondentes.
	 * 
     * @memberof pagesService
     * @function
     * 
     * @return {Object} Página
	 */
	this.getPageByName = function(name) {
		var pages = _this.getPagesForConfiguration();
		var page = null;
		
		var i = 0;
		while (i < pages.length && page === null) {
			if (pages[i].name == name) {
				page = pages[i];
			}
			
			i++;
		}
		
		return page;
	};
	
    /**
     * Busca os dados do menu
     *
     * @memberof pagesService
     * @function
     * 
     * @return {Array<Object>} Dados do menu
     */
	this.getMenuPages = function () {
		
    	var courseMenu = _this.getCourseMenu();
    	var pages = [];
		
		for(i = 0, size = courseMenu.length; i < size; i++) {
			var coursePage = courseMenu[i] - 1; // índice da página = identificador - 1		
			var page = PAGES_DATA[coursePage];
						
			pages.push(page);
		}
		
		pages.push(PAGES_DATA[PAGES.CONFIGURATION - 1]);
		pages.push(PAGES_DATA[PAGES.LOGOUT - 1]);
			
		return pages;
	};
	
    /**
     * Busca os menus habilitados para o curso
     *
     * @memberof pagesService
     * @function
     * 
     * @return {Array<number>} Menus configurados
     */
	this.getCourseMenu = function() {
		var studentCourseLevel = localStorageService.get(STUDENT_COURSE_LEVEL_KEY);
    	
    	if (menu == null || menu.length == 0) {
    		var lastMenu = localStorageService.get(LAST_MENU);
    		
    		menu = lastMenu != null ? lastMenu : CONFIG.DEFAULT_MENU;
    	} 
		
    	return studentCourseLevel == UNDERGRADUATE ? menu.GRADUACAO : menu.POSGRADUACAO;
	}
			
    /**
     * Busca o menu
     *
     * @memberof pagesService
     * @function
     * 
     * @return {Object} Promessa com resultado da requisição
     */
    this.getMenu = function () {    	    	
    	deferredResponse = $q.defer();
    	
    	var studentId = localStorageService.get("studentCourseChosen");
    	
        var config = {
            params: {
                token: CONFIG.UNISUAM_APP_TOKEN
            }
        };
    	
        $http.get(CONFIG.SERVICES.MENU, config).then(handleSuccess, handleError);
    	                
    	return deferredResponse.promise; 
    };
    
    /**
     * Método chamado quando a busca do menu for finalizada com sucesso
     *
     * @memberof pagesService
     * @private
     * @function
     * @method success
     * 
     * @param {Object} result Resultado, inclui a configuração da requisição, cabeçalho e status
     */
    function handleSuccess(result) {        	
        if (result.data.errors != null && result.data.errors.length > 0) {
            for (var i = 0, len = result.data.errors.length; i < len; i++) {
                $log.error(result.data.errors[i].message);
            }           
            
            handleError();
            
        } else if (result.data.data != null) {            
        	if (result.data.data.length > 0) {    	
        		menu = result.data.data;
        		localStorageService.set(LAST_MENU, menu);
        	}
        	
        	deferredResponse.resolve(_this.getMenuPages());
        }
    }
    
    
    /**
     * Exibe uma mensagem de erro ocorrido numa requisição
     *
     * @memberof pagesService
     * @protected
     * @function
     * 
     * @param {Object} errorResult Informações do erro ocorrido
     */
    function handleError(errorResult) {    	
    	if (errorResult !== null) {
    		$log.error(errorResult.message);
    	}
    	
    	deferredResponse.resolve(_this.getMenuPages());
    };
}]);