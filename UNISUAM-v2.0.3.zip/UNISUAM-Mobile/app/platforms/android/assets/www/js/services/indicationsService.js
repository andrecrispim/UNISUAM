/**
 * Serviço responsável por buscar e salvar Indicações no servidor remoto
 *
 * @class
 * @name indicationsService
 * 
 * @param {Object} $http Serviço HTTP
 * @param {localStorageService} localStorageService Serviço de armazenamento local
 * @param {CONFIG} CONFIG Configuração
 */
app.service('indicationsService', ['$http', 'localStorageService', 'CONFIG',
                                  function ($http, localStorageService, CONFIG) {
    /**
     * Busca as indicações feitas pelo aluno
     *
     * @memberof indicationsService
     * @function
     * 
     * @param {number} studentId Identificador do aluno
     * 
     * @return {Object} Promessa com o resultado da requisição
     */
    this.getIndications = function (studentId) {
        var config = {
            params: {
                token: CONFIG.UNISUAM_APP_TOKEN
            }
        };
        
        var url = CONFIG.SERVICES.INDICATIONS;
        url = url + "/" + localStorageService.get('studentCourseChosen');

        return $http.get(url, config);
    };
    
    /**
     * Registra uma nova indicação
     * 
     * @memberof indicationsService
     * @function
     * 
     * @param {Object} Indicação
     * 
     * @return {Object} Promessa com o resultado da requisição 
     */
    this.register = function (indication) {
        var config = {
            params: {
                token: CONFIG.UNISUAM_APP_TOKEN
            }
        };
        
        var url = CONFIG.SERVICES.INDICATIONS;
        url = url + "/" + localStorageService.get('studentCourseChosen');
        
        return $http.post(url, config);
    }
}]);