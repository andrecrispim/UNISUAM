
var pushModule = angular.module("PushModule");

/**
 * Serviço de criptografia
 * 
 * @class
 * @name encryptionFactory
 * 
 * @param {Object} CONFIG 
 */
pushModule.service("encryptionFactory", ["CONFIG", function(CONFIG) {
	var secret = CONFIG.SECRET;

	var auth = {
		appId : CONFIG.APP_ID,
		timestamp : Math.floor((new Date).getTime() / 1000),
		signature : null
	};
	
	/**
	 * Criptografa dados
	 * 
	 * @memberof encryptionFactory
	 * @function
	 * 
	 * @param {string} Dados
	 * 
	 * @returns {string} Dados criptografados
	 */
	this.encrypt = function(dataJson) {
		var tokenData = auth.appId + secret + auth.timestamp + dataJson;
		auth.signature = CryptoJS.HmacSHA256(tokenData, secret).toString(CryptoJS.enc.Base64);
		var authString = JSON.stringify(auth);
		var authParsed = CryptoJS.enc.Utf8.parse(authString);
		var authEncoded = CryptoJS.enc.Base64.stringify(authParsed);

		return authEncoded;
	}
}]);