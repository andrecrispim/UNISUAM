"use strict";

/**
 * Controlador da tela de boletim da graduação
 *
 * @class
 * @name undergraduateReportCardController
 * 
 * @param {Object} $scope Escopo
 * @param {reportCardService} reportCardService Serviço para busca do boletim
 */
function undergraduateReportCardController($scope, reportCardService) {
	/**
	 * Indica se houve erro a busca retornou erro
	 * 
	 * @type {boolean}
	 */
    $scope.hasError = false;
        
    /**
     * Indica se um boletim foi retornado
     * 
     * @type {boolean}
     */
    $scope.hasReportCard = false;

	/**
     * Inicializa a tela
     *
     * @memberof undergraduateReportCardController
     * @function
     */
    $scope.init = function () {
        reportCardService.getReportCard().then(handleSuccess, function (result) {
            $scope.handleError(result, $scope.dialog);
        });
    };

    /**
     * Método chamado quando a busca do boletim for finalizada com sucesso
     *
     * @memberof undergraduateReportCardController
     * @private
     * @function
     * @method success
     * 
     * @param {Object} result Resultado, inclui a configuração da requisição, cabeçalho e status
     */
    function handleSuccess(result) {
        $scope.reportCard = result.data.data;
        
        $scope.hasReportCard = ($scope.reportCard != null);        
        $scope.messages.length = 0;
        
        if (result.data.errors != null && result.data.errors.length > 0) {
            for (var i = 0, len = result.data.errors.length; i < len; i++) {
                $scope.messages.push(result.data.errors[i].message);
            }
        } else if ($scope.reportCard == null) {
            $scope.messages.push("Não há dados cadastrados até o momento.");
        } else {
            // ordena
            var colunas = [];
            
            Object.keys($scope.reportCard.colunas).forEach(function (key) {
                colunas.push({key: key, value: $scope.reportCard.colunas[key]});
            });

            $scope.disciplinesHeader = colunas;
            $scope.disciplinesBody = $scope.reportCard.resultados;
        }


        $scope.hideLoading();
    }
}