"use strict";

/**
 * Controlador da tela de notícias
 *
 * @class
 * @name newsController
 * 
 * @param {Object} $scope Escopo
 * @param {object} $sce Serviço de contexto para garantir que um dado é seguro 
 * @param {newsService} newsService Serviço de busca de notícias
 * @param {environmentService} environmentService Serviço de informações do ambiente
 * @param {localStorageService} localStorageService Serviço de armazenamento local
 */
function newsController($scope, $sce, $timeout, newsService, environmentService, localStorageService) {
    var _this = this;
    page.call(this, $scope, environmentService);

    /**
     * Indica se retornou com erros
     * 
     * @type {boolean}
     */
    $scope.hasError = false;
    
    /**
     * Indica se encontrou notícias
     * 
     * @type {boolean}
     */
    $scope.hasNews = false;
    
    /**
     * Mensagem a ser exibida
     * 
     * @type {string}
     */
    $scope.message = null;

    /**
     * Trata o evento disparado quando um repeater termina
     *
     * @param {Object} ngRepeatFinishedEvent Evento
     */
    $scope.$on('ngRepeatFinished', function (ngRepeatFinishedEvent) {
        _this.refresh();

        // altera todos os links de forma que abram em uma nova janela
        $(".news-page a").click(function () {
            var url = $(this).attr('href');
            window.open(encodeURI(url), '_system', 'location=yes');
            return false;
        });

        // atualiza a página quando uma imagem for carregada
        $(".news-page img").bind("load", function () {
            $timeout(function () {
                _this.refresh();
            }, 50);
        });
    });

    /**
     * Inicializa a tela
     *
     * @memberof newsController
     * @function
     */
    $scope.init = function () {
        _this.showLoading();
        $scope.pageTitle = "Notícias";
        $scope.newsData = null;
        
        newsService.getNews().then(handleSuccess, function (result) {
            _this.handleError(result, $scope.dialog);
        });
    };

    /**
     * Garante que o html recebido seja seguro
     *
     * @memberof newsController
     * @function
     * 
     * @param {string} html HTML
     * 
     * @return {string} HTML
     */
    $scope.trustAsHtml = function (html) {
        return $sce.trustAsHtml(html);
    };

    /**
     * Método chamado quando a busca de notícias terminar com sucesso
     *
     * @memberof newsController
     * @private
     * @function
     * @method success
     * 
     * @param {Object} result Resultado, inclui a configuração da requisição, cabeçalho e status
     */
    function handleSuccess(result) {

        $scope.newsData = result.data;

        var studentCourseLevel = localStorageService.get("studentCourseLevel");
        $scope.isUndergraduate = studentCourseLevel == "GRADUACAO";

        if ($scope.isUndergraduate) {
            $scope.hasError = $scope.newsData.errors != null && $scope.newsData.errors.length > 0;

            if ($scope.hasError) {
                $scope.message = $scope.newsData.errors[0].message;
            } else {
                $scope.hasNews = $scope.newsData.data != null && $scope.newsData.data.length != 0;

                if ($scope.hasNews) {
                    $scope.allNews = $scope.newsData.data;
                } else {
                    $scope.message = "Não há notícias cadastradas até o momento.";
                }
            }
        } else {
            $scope.hasError = $scope.newsData.errors != null && $scope.newsData.errors.length > 0;

            if ($scope.hasError) {
                $scope.message = $scope.newsData.errors[0].message;
            } else {
                $scope.hasNews = $scope.newsData.data != null && $scope.newsData.data.length != 0;

                if ($scope.hasNews) {
                    $scope.allNews = $scope.newsData.data;
                } else {
                    $scope.message = "Não há notícias cadastradas até o momento.";
                }
            }
        }

        _this.hideLoading();
    }
}

newsController.prototype = Object.create(page.prototype);