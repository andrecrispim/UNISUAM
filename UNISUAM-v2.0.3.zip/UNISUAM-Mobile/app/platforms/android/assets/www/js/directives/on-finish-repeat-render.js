/**
 * Diretiva que dispara um evento quando um ng-repeat terminar de ser renderizado
 *
 * @class
 * @name onFinishRepeatRender
 * 
 * @param {Object} $timeout Serviço de timeout
 */
app.directive('onFinishRepeatRender', function($timeout) {
  return {
    restrict : 'A',
    link : function(scope, element, attr) {
      if (scope.$last === true) {
        $timeout(function() {
          scope.$emit('ngRepeatFinished');
        });
      }
    }
  };
});