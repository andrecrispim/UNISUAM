var configuration = angular.module('config', []);

/**
 * Configuration
 *
 * @name CONFIG
 * @const
 */
configuration.constant("CONFIG", {
    APP_ID: 1,
    SECRET: "xomfjYkBJJ2JlMaTCa6z6aaUcz8YfPrjeDXcOx4QF48=",
    UNISUAM_APP_TOKEN: "581d82c8000c70ea2029d3a1297a3d41",
    REQUEST_TIMEOUT: 60000,
    LOG: {
        LEVEL: 2, // 0 = ERROR, 1 = WARN, 2 = INFO, 3 = DEBUG
        REMOTE_LOG_LEVEL: 1,
        ENABLED: false,
        TOKEN: 'cb75c94d-73c0-406c-a72b-5472f7170a53',
        VISUAL_STUDIO: false // força o log para visual studio (usa só o $log.debug)
    },
    CACHE: {
        ENABLED: true,   // habilita ou desabilita o cache das páginas
        MAX_AGE: 600000, //10 minutes
        FLUSH_INTERVAL: 6000000 //1 hour
    },
    DEFAULT_MENU : {
    	GRADUACAO: [1, 2, 3, 4, 5, 6],
    	POSGRADUACAO: [1, 2, 4, 5, 6]
    },

    //Environment: Production
//    SERVICES: {
//        DEVICES: "http://push-notification.unisuam.edu.br/api.php/devices",
//        LOGIN: "http://api-authentication-aluno.unisuam.edu.br/api/unisuam-api-authentication-aluno-login-generico/v2",
//        UNDERGRADUATE: {
//            EXAMS: "http://apicms.unisuam.edu.br/api/cms-graduacao-aluno-quadro-horario/getQuadroHorario",
//            NEWS: "http://apicms.unisuam.edu.br/api/cms-informacao-noticia-mobile",
//            REPORT_CARD: "http://apicms.unisuam.edu.br/api/cms-graduacao-aluno-boletim/getBoletim",
//            SCHEDULES: "http://apicms.unisuam.edu.br/api/cms-graduacao-aluno-quadro-horario/getQuadroHorario",
//            FINANCES: "http://apicms.unisuam.edu.br/api/cms-graduacao-aluno-ficha-financeira"
//        },
//        GRADUATION: {
//            REPORT_CARD: "http://apicms.unisuam.edu.br/api/cms-pos-graduacao-aluno-boletim",
//            SCHEDULES: "http://apicms.unisuam.edu.br/api/cms-pos-graduacao-aluno-quadro-horario",
//            FINANCES: "http://apicms.unisuam.edu.br/api/cms-pos-graduacao-aluno-ficha-financeira",
//            NEWS: "http://apicms.unisuam.edu.br/api/cms-informacao-noticia-mobile"
//        },
//        COURSELIST: "http://apicms.unisuam.edu.br/api/cms-usuario/get-cursos-by-unique-id",
//    	  MENU: "http://apicms.unisuam.edu.br/api/cms-mobile/menu"
//    },
//    PUSH_NOTIFICATION: {
//        SENDER_ID: "SUBSTITUA-production-sender-id"
//    },
//    ANALYTICS: {
//    	UA: 'UA-67593803-1'
//    }

    // Environment: Development
    SERVICES: {
        DEVICES: "http://10.0.101.88:8080/push/api.php/devices",
        LOGIN: "http://api-authentication-aluno-dev.unisuam.edu.br/api/unisuam-api-authentication-aluno-login-generico/v2",
        UNDERGRADUATE: {
            EXAMS: "http://apicms-dev.unisuam.edu.br/api/cms-graduacao-aluno-quadro-horario/getQuadroHorario",
            NEWS: "http://apicms-dev.unisuam.edu.br/api/cms-informacao-noticia-mobile",
            REPORT_CARD: "http://apicms-dev.unisuam.edu.br/api/cms-graduacao-aluno-boletim/getBoletim",
            SCHEDULES: "http://apicms-dev.unisuam.edu.br/api/cms-graduacao-aluno-quadro-horario/getQuadroHorario",
            FINANCES: "http://apicms-dev.unisuam.edu.br/api/cms-graduacao-aluno-ficha-financeira"
        },
        GRADUATION: {
            REPORT_CARD: "http://apicms-dev.unisuam.edu.br/api/cms-pos-graduacao-aluno-boletim",
            SCHEDULES: "http://apicms-dev.unisuam.edu.br/api/cms-pos-graduacao-aluno-quadro-horario",
            FINANCES: "http://apicms-dev.unisuam.edu.br/api/cms-pos-graduacao-aluno-ficha-financeira",
            NEWS: "http://apicms-dev.unisuam.edu.br/api/cms-informacao-noticia-mobile"
        },
        COURSELIST: "http://apicms-dev.unisuam.edu.br/api/cms-usuario/get-cursos-by-unique-id",
        INDICATIONS: "http://private-b8386-unisuam.apiary-mock.com/indications",
        MENU: "http://apicms-dev.unisuam.edu.br/api/cms-mobile/menu"
    },
    PUSH_NOTIFICATION: {
        SENDER_ID: "425290692764"
    },
    ANALYTICS: {
    	UA: 'UA-67593803-1'
    }
});
