/**
 * Diretiva que dispara um evento quando o teclado virtual for fechado
 * 
 * @class
 * @name onHideKeyboard
 */
app.directive('onHideKeyboard', function() {
	return function($scope, $element) {		
		document.addEventListener('hidekeyboard', function(e) {
			$element[0].scrollTop = 0;
		});
	}
})
