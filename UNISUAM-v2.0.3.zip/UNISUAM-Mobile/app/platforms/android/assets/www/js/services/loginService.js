/**
 * Serviço responsável por efetuar o login do aluno
 *
 * @class
 * @name loginService
 * 
 * @param {Object} $http Serviço HTTP
 * @param {CONFIG} CONFIG Configuração
 */
app.service('loginService', ['$http', 'CONFIG', function ($http, CONFIG) {

	/**
     * Performs user login
     *
     * @memberof loginService
     * @function
     * 
     * @param {string} userLogin Login do aluno (CPF ou Còdigo do Curso)
     * @param {string} userPass Senha
     * 
     * @returns {Object} Promessa com o resultado da requisição
     */
    this.undergraduateVerifyLogin = function (userLogin, userPass) {
        var url = CONFIG.SERVICES.LOGIN;

        var data = "username=" + userLogin + "&password=" + userPass;
        
        var config = {
            headers: {
                'Content-Type': 'application/x-www-form-urlencoded'
            }
        };

        return $http.post(url, data, config);
    };
}]);