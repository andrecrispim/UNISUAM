/**
 * Serviço que disponibiliza informações sobre o ambiente
 *
 * @class
 * @name environmentService
 */
app.service('environmentService', function () {

	var DEVICE_TYPE = {
		ANDROID: 1,
		IOS: 2,
		WINDOWS_PHONE: 3		
	};
	
    /**
     * Indica se é um Android
     *
     * @memberof environmentService
     * @function
     * 
     * @return {boolean} True se for Android, false caso contrário
     */
    this.isAndroid = function() {
        return window.device != null && window.device.platform.toLowerCase() == 'android';
    }
    
    /**
     * Indica se é um Android 2 (API 10)
     *
     * @memberof environmentService
     * @function
     * 
     * @return {boolean} True se for Android 2, false caso contrário
     */
    this.isAndroid2 = function() {
        if (!this.isAndroid()) {
            return false;
        }

        // obtém a versão do Android
        var androidVersionIndex = window.device.version.indexOf(".");
        androidVersion = window.device.version.substring(0, androidVersionIndex);
        return androidVersion == '2';
    };
    
    /**
     * Indica se é um iOS
     *
     * @memberof environmentService
     * @function
     * 
     * @return {boolean} True se for iOS, false caso contrário 
     */
    this.isIOS = function() {
    	return window.device != null && window.device.platform.toLowerCase() == "ios";	
    };
    
    /**
     * Indica se é um Windows Phone
     * 
     * @memberof environmentService
     * @function
     * 
     * @return {boolean} True se for Windows Phone, false caso contrário
     */
    this.isWindowPhone = function() {        
        return window.device != null && window.device.platform.toLowerCase() == 'win32nt';
    }
    
    /**
     * Retorna o tipo de dispositivo
     * 
     * @memberof environmentService
     * @function
     * 
     * @return {number} Device type
     */
    this.getDeviceType = function() {
    	if (this.isAndroid()) {
    		return DEVICE_TYPE.ANDROID;
    	} else if (this.isIOS()) {
    		return DEVICE_TYPE.IOS;    		
    	} else if (this.isWindowPhone()) {
    		return DEVICE_TYPE.WINDOWS_PHONE;
    	}
    	
    	return -1;
    }
});