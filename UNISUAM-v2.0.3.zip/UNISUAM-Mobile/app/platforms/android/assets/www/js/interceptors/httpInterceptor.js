/**
 * Interceptador de requisições HTTP
 * 
 * @class
 * 
 * @param {Object} $q Promessa
 * @param {CONFIG} CONFIG Configuração
 * @param {Object} $log Log
 * 
 * @return {httpInterceptor}
 */
app.factory('httpInterceptor', ['$q', 'CONFIG', '$log', function($q, CONFIG, $log) {
	
	var httpInterceptor = {};

	/**
	 * Intercepta uma requisição
	 * 
	 * Este método é chamado antes de a requisição ser enviada ao servidor
	 * 
	 * @memberof httpInterceptor
	 * @function
	 * 
	 * @param {Object} config Configuração da requisição
	 * 
	 * @returns {Object} Configuração da requisição alterada
	 */
	httpInterceptor.request = function(config) {
		config.timeout = CONFIG.REQUEST_TIMEOUT;
		config.cache = CONFIG.CACHE.ENABLED;
		return config;
	};

	/**
	 * Intercepta a resposta
	 * 
	 * Método chamado quando o serviço $http recebe a resposta do backend.
	 * 
	 * @memberof httpInterceptor
	 * @function
	 * 
	 * @param {Object} response Resposta, inclui a configuração da requisição, cabeçalho e status
	 * 
	 * @return {Object} Resposta ou Promessa
	 */
	httpInterceptor.response = function(response) {
		// até mesmo as páginas locais são capturadas aqui
		if (response.config.url != null && response.config.url.indexOf("http") > -1) {
			$log.info("Requisição finalizada com sucesso: " + response.config.url);

			if (response.config.params != null) {
				$log.info("token: " + response.config.params.token + " matricula: "
						+ response.config.params.matricula);
			}
		}

		return response;
	};

	/**
	 * Intercepta uma resposta de erro
	 * 
	 * Método chamado quando uma requisição falha.
	 * 
	 * @memberof httpInterceptor
	 * @function
	 * 
	 * @param {Object} rejection Resposta, inclui a configuração da requisição, cabeçalho e status
	 * 
	 * @return {Object} Resposta ou Promessa
	 */
	httpInterceptor.responseError = function(rejection) {
		$log.error("Ocorreu um erro ao efetuar a requisição. Status: " + rejection.status + " - "
				+ rejection.statusText + " - " + rejection.config.url);

		if (rejection.config.params != null) {
			$log.error("Request data - token: " + rejection.config.params.token + " matricula: "
					+ rejection.config.params.matricula);
		}

		var statusMessage = "Não foi possível efetuar a operação, tente novamente.";

		switch (rejection.status) {
		case 0:
			// verifica se o dispositivo possui uma conexão ativa
			if (!navigator.onLine) {
				statusMessage = "Não há uma conexão ativa com a internet.";
				rejection.status = -1;
			}

			break;
		case 408:
			statusMessage = "O servidor não respondeu.";
			break;
		case 500:
			statusMessage = "O servidor retornou um erro.";
			break;
		}

		rejection.message = statusMessage;

		return $q.reject(rejection);
	}

	return httpInterceptor;
}]);