/**
 * Serviço responsável por buscar o Quadro de Horário no servidor remoto
 *
 * @class
 * @name schedulesService
 * 
 * @param {Object} $http Serviço HTTP
 * @param {localStorageService} localStorageService Serviço de armazenamento local
 * @param {CONFIG} CONFIG Configuração
 */
app.service('schedulesService', ['$http', 'localStorageService', 'CONFIG',
                                 function ($http, localStorageService, CONFIG) {
    var UNDERGRADUATE = 'GRADUACAO';

    /**
     * Busca o quadro de horário da disciplina atual
     *
     * @memberof schedulesService
     * @function
     * 
     * @return {Object} Promessa com o resultado da consulta
     */
    this.getSchedules = function () {
        var studentCourseLevel = localStorageService.get('studentCourseLevel');
        var url = null;
        
        var config = {
            params : {
                token : CONFIG.UNISUAM_APP_TOKEN
            }
        };

        if (studentCourseLevel == UNDERGRADUATE) {
            url = CONFIG.SERVICES.UNDERGRADUATE.SCHEDULES;

            var data = 'core_usuario_tipo_usuario_id=' + localStorageService.get('studentCourseChosen');

            return $http.post(url, data, {headers: {'Content-Type': 'application/x-www-form-urlencoded; charset=UTF-8'}});
        } else {
            url = CONFIG.SERVICES.GRADUATION.SCHEDULES;
            url = url + "/" + localStorageService.get('studentCourseChosen');

            return $http.get(url, config);
        }
    };
}]);