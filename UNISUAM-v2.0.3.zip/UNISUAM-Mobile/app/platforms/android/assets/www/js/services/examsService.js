/**
 * Serviço responsável por buscar as provas no servidor remoto
 *
 * @class
 * @name examsService
 * 
 * @param {Object} $http Serviço HTTP
 * @param {localStorageService} localStorageService Serviço de armazenamento local
 * @param {CONFIG} CONFIG Configuração
 */
app.service('examsService', ['$http', 'localStorageService', 'CONFIG',
                             function ($http, localStorageService, CONFIG) {
    /**
     * Busca as provas do curso atual
     *
     * @memberof examsService
     * @function
     * 
     * @return {Object} Promessa com o resultado da consulta
     */
    this.getExams = function () {
        var url = CONFIG.SERVICES.UNDERGRADUATE.EXAMS;
        var data = 'core_usuario_tipo_usuario_id=' + localStorageService.get('studentCourseChosen');

        return $http.post(url, data, {headers: {'Content-Type': 'application/x-www-form-urlencoded; charset=UTF-8'}});
    };
}]);