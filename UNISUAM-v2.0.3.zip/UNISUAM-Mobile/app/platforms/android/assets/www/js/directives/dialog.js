
/**
 * Diretiva para exibição de diálogo
 * 
 * @class
 * @name dialog 
 * 
 * @param {Object} $window Janela
 */
app.directive('dialog', [ '$window', function($window) {
  return {
    scope: {
      message: "@",
      title : "@",
      type: "@",
      image_src : "@",
      api: "="
    },
    restrict : 'E',
    replace : true,
    templateUrl: 'views/shared/dialog.html',
    controller : ['$scope', "environmentService", function($scope, environmentService) {

      var topBar = $("#topBar");
      var errorClass = "alert";
      var warningClass = "warning";
      var successClass = "success";
      var ERROR = "error";
      var SUCCESS = "success";
      var WARNING = "warning";

      $scope.api = {    	
        /**
         * Exibe um diálogo de error
         * 
         * @memberof dialog
         * @function
         * 
         * @param {string} message Mensagem
         */
        error : function(message) {
          $scope.title = "Sentimos muito!";
          $scope.image_src = null;
          $scope.message = message;

          if (environmentService.isAndroid2()) {
            navigator.notification.alert($scope.message, null, $scope.title);
          }else {
            $scope.api.show(ERROR);
          }
        },

        /**
         * Exibe um diálogo de alerta
         * 
         * @memberof dialog
         * @function
         * 
         * @param {string} message Mensagem
         */
        warning : function(message) {
          $scope.message = message;
          $scope.image_src = null;
          $scope.title = "Alerta!";

          if (environmentService.isAndroid2()) {
            navigator.notification.alert($scope.message, null, $scope.title);
          }else {
            $scope.api.show(WARNING);
          }
        },

        /**
         * Exibe um diálogo de sucesso
         * 
         * @memberof dialog
         * @function
         * 
         * @param {string} message Mensagem
         */
        success : function(message) {
          $scope.message = message;
          $scope.image_src = null;
          $scope.title = "Sucesso!";

          if (environmentService.isAndroid2()) {
            navigator.notification.alert($scope.message, null, $scope.title);
          }else {
            $scope.api.show(SUCCESS);
          }
        },

        /**
         * Exibe uma notificação
         * 
         * @memberof dialog
         * @function
         * 
         * @param {string} message Mensagem
         * @param {string} Url da imagem
         */
        notification : function(message, imageSource) {
          $scope.message = message;
          $scope.image_src = imageSource;
          $scope.title = "Notificação!";

          if (environmentService.isAndroid2()) {
            navigator.notification.alert($scope.message, null, $scope.title);
          } else {
            $scope.api.show(null);
          }
        },

        /**
         * Exibe o diálogo
         * 
         * @memberof dialog
         * @function
         * 
         * @param {string} type Tipo do diálogo
         */
        show : function(type) {
          if (type != null) {
            $scope.type = type;
          }

          topBar.removeClass(errorClass);
          topBar.removeClass(warningClass);
          topBar.removeClass(successClass);

          switch ($scope.type) {
          case ERROR:
            topBar.addClass(errorClass);
            break;
          case SUCCESS:
            topBar.addClass(successClass);
            break;
          case WARNING:
            topBar.addClass(warningClass);
            break;
          }
          $('#alertModal').foundation('reveal', 'open');
        },

        /**
         * Fecha o diálogo
         * 
         * @memberof dialog
         * @function
         */
        dismiss : function() {
          $('#alertModal').foundation('reveal', 'close');
        }
      };

      /**
       * Trata o evento disparado pelo push ao receber uma notificação
       * 
       * @param {Object} event Evento
       * @param {Array} args Parâmetros
       */
      $scope.$on("NotificationReceived", function(event, args) {
        $scope.api.notification(args.message, args.imageSource);
      });

      /**
       * Trata o evento disparado pelo push ao receber um erro
       * 
       * @param {Object} event Evento
       * @param {Array} args Parâmetros
       */
      $scope.$on("ErrorReceived", function(event, args) {
        $scope.api.error(args.message);
      });
    }]
  };
}]);