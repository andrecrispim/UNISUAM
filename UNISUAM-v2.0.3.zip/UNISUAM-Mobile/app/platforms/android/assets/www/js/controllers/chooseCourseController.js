"use strict";

/**
 * Controlador da tela de escolha de curso
 *
 * @class
 * @name chooseCourseController
 * 
 * @param {Object} $scope Escopo
 * @param {Object} $log Log
 * @param {Object} $location Serviço de local
 * @param {localStorageService} localStorageService Serviço de armazenamento local
 * @param {Object} $analytics Serviço para coletar dados analíticos
 */
function chooseCourseController($scope, $log, $location, localStorageService, $analytics) {
    
	/**
     * Inicializa
     *
     * @memberof chooseCourseController
     * @function
     */
    $scope.init = function () {
        $scope.coursesUndergraduate = null;
        $scope.coursesGraduation = null;
        $scope.getLocalStorageCourses();
        
        document.getElementById("loading-modal").style.display = "none";
    };

    /**
     * Busca a lista de cursos a ser exibida
     *
     * @memberof chooseCourseController
     * @function
     */
    $scope.getLocalStorageCourses = function () {
        if (localStorageService.get('logged')) {
            if (localStorageService.get('coursesUndergraduate')) {
                $scope.coursesUndergraduate = localStorageService.get('coursesUndergraduate');
            }

            if (localStorageService.get('coursesGraduation')) {
                $scope.coursesGraduation = localStorageService.get('coursesGraduation');
            }
        } else {
            $location.path("/");
        }
    };

    /**
     * Método chamado quando o usuário escolhe um curso, salva os dados do curso selecionado
     *
     * @memberof chooseCourseController
     * @function
     * 
     * @param {number} courseType Tipo do curso
     */
    $scope.goToCourse = function (courseType) {
        document.getElementById("loading-modal").style.display = "block";
        
        var course = courseType == 0 ? $scope.coursesUndergraduate[0] : $scope.coursesGraduation[0];
        
        $analytics.eventTrack("Curso Nível", {category: "CONFIGURATION", label: course.nivel_de_ensino});
        $analytics.eventTrack("Curso", {category: "CONFIGURATION", label: course.curso_nome});                 
        
        localStorageService.set('studentCourseLevel', course.nivel_de_ensino);
        localStorageService.set('studentCourseChosen', course.aluno_id);        
        localStorageService.set('studentNumber', course.aluno_matricula);
        localStorageService.set('studentCourseName', course.curso_nome);

        $location.path("/news");
    };
}
