"use strict";

/**
 * Controlador básico das telas de boletim
 *
 * @class
 * @name reportCardController
 * 
 * @param {Object} $scope Escopo
 * @param {localStorageService} localStorageService Serviço de armazenamento local
 * @param {reportCardService} reportCardService Serviço para busca do boletim
 * @param {environmentService} environmentService Serviço de informações do ambiente
 */
function reportCardController($scope, localStorageService, environmentService) {
    var _this = this;
    page.call(this, $scope, environmentService);

    /**
     * Cabeçalhos das disciplinas
     * 
     * @type {Array.<string>}
     */
    $scope.disciplinesHeader = null;
    
    /**
     * Dados das disciplinas
     * 
     * @type {Array.<Object>}
     */
    $scope.disciplinesBody = null;
    
    /**
     * Nível do curso atual
     * 
     * @type {string}
     */
    $scope.studentCourseLevel = null;

    /**
     * Método chamado quando a busca retornar com erro
     * 
     * @memberof reportCardController
     * @function
     */
    $scope.handleError = function (errorResult, dialog) {
        _this.handleError(errorResult, dialog);
    };

    /**
     * Esconde a view de progresso
     * 
     * @memberof reportCardController
     * @function
     */
    $scope.hideLoading = function () {
        _this.hideLoading();
    };

    /**
     * Trata o evento disparado quando um repeater termina
     *
     * @param {Object} ngRepeatFinishedEvent Evento
     */
    $scope.$on('ngRepeatFinished', function (ngRepeatFinishedEvent) {
        _this.refresh();
    });

    /**
     * Inicializa a tela
     *
     * @memberof reportCardController
     * @function
     */
    $scope.init = function () {
        _this.showLoading();
        $scope.pageTitle = "Boletim";

        $scope.studentCourseLevel = localStorageService.get('studentCourseLevel');
    };
}

reportCardController.prototype = Object.create(page.prototype);