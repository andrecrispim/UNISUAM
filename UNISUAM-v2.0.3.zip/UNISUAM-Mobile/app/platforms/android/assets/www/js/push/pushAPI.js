
var pushModule = angular.module("PushModule");

/**
 * API de push
 * 
 * Registra, desregistra e atualiza o dispositivo no backend.
 * 
 * @class
 * @name pushAPI
 * 
 * @param {Object} $http Serviço para comunicação com o backend
 * @param {Object} $log Log
 * @param {CONFIG} CONFIG Configuração
 * @param {Object} $rootScope Escopo principal
 * @param {encryptionFactory} Classe para encriptar dados
 * 
 * @return {pushAPI}
 */
pushModule.factory("pushAPI", ["$http", "CONFIG", "$rootScope", "$log", "encryptionFactory", 
                               function($http, CONFIG, $rootScope, $log, encryptionFactory) {	
	var pushAPI = {};
	
	var ACTIVING_ERROR_MESSAGE = "Não foi possível ativar as notificações neste momento.";
	var NO_INTERNET_ERROR_MESSAGE = "Não foi possível ativar as notificações neste momento. O dispositivo está offline.";

	/**
	 * Cria uma requisição http
	 * 
     * @memberof pushAPI
     * @private
     * @function
     * 
     * @param {string} method Método HTTP
     * @param {Object} pushInfo Dados a serem enviado
     * 
     * @returns {Object} Dados da requisição
	 */
	function requestContent(method, pushInfo) {
		var method = method.toUpperCase();
		var url = CONFIG.SERVICES.DEVICES;
		var dataJson = JSON.stringify(pushInfo);
		var authEncoded = "Bearer " + encryptionFactory.encrypt(dataJson);
		var timeout = CONFIG.REQUEST_TIMEOUT;

		return {
			method : method,
			url : url,
			data : dataJson,
			headers : {
				UnisuamAuth : authEncoded
			},
			timeout : timeout
		};
	};

	/**
	 * Método chamado quando o registro do dispositivo para push for feito com sucesso
	 * 
     * @memberof pushAPI
     * @private
     * @function
     * 
     * @param {Object} data Dados do registro
     * @param {Object} status Status HTTP
	 */
	function registrationSuccessCallback(data, status) {
		$rootScope.setIsRegisteredForPush(true);
		$log.debug(data);
	};

	/**
	 * Método chamado quando ocorrer erro ao registrar o dispositivo
	 * 
     * @memberof pushAPI
	 * @private
     * @function
     * 
     * @param {Object} data Dados do erro
     * @param {Object} status Status HTTP
	 */
	function registrationErrorCallback(data, status) {
		switch(status) {
		case -1:
			$rootScope.setToken("");
			$log.error(data);
			$rootScope.$broadcast("ErrorReceived", { message : NO_INTERNET_ERROR_MESSAGE });
			break;
		case 409:
			var token = $rootScope.token();

			var pushInfo = {
				oldToken : token,
				newToken : token,
				userId : $rootScope.userId()
			};

			pushAPI.update(pushInfo);

			$log.warn(data);
			break;
		default:
			$rootScope.setToken("");
			$log.error(data);
			$rootScope.$broadcast("ErrorReceived", { message : ACTIVING_ERROR_MESSAGE });
		}
	};

	/**
	 * Método chamado quando o registro do dispositivo para push for removido com sucesso
	 * 
     * @memberof pushAPI
     * @private
     * @function
     * 
     * @param {Object} data Dados do registro
     * @param {Object} status Status HTTP
	 */
	function unregistrationSuccessCallback(data, status) {
		$rootScope.setIsRegisteredForPush(false);
		$rootScope.setToken("");
		$log.log(data);
	};

	/**
	 * Método chamado quando ocorrer erro desregistrar do dispositivo
	 * 
     * @memberof pushAPI
     * @private
     * @function
	 */
	function unregistrationErrorCallback(data, status) {
		$log.error(data);
	};
	
	/**
	 * Registra o dispositivo para push
	 * 
     * @memberof pushAPI
     * @function
     * 
     * @param {Object} pushInfo Dados a serem enviado
	 */
	pushAPI.register = function(pushInfo) {
		var request = requestContent("POST", pushInfo);
		$http(request).success(registrationSuccessCallback).error(registrationErrorCallback);
	};
	
	/**
	 * Atualiza o registro do dispositivo
	 * 
     * @memberof pushAPI
     * @function
     * 
     * @param {Object} pushInfo Dados a serem enviado
	 */
	pushAPI.update = function(pushInfo) {
		var request = requestContent("PUT", pushInfo);
		$http(request).success(registrationSuccessCallback).error(registrationErrorCallback);
	};
	
	/**
	 * Desregistra o dispositivo
	 * 
     * @memberof pushAPI
     * @function
     * 
     * @param {Object} pushInfo Dados a serem enviado
	 */
	pushAPI.unregister = function(pushInfo) {
		var request = requestContent("DELETE", pushInfo);
		$http(request).success(unregistrationSuccessCallback).error(unregistrationErrorCallback);
	}
		
	return pushAPI;
}]);