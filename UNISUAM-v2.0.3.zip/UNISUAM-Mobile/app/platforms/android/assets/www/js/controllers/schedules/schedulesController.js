"use strict";

/**
 * Controlador das telas do quadro de horário
 *
 * @class
 * @name schedulesController
 * 
 * @param {Object} $scope Scope
 * @param {localStorageService} localStorageService Serviço de armazenamento local
 * @param {schedulesService} schedulesService Serviço para busca o quadro de horário
 * @param {environmentService} environmentService Serviço de informações do ambiente
 */
function schedulesController($scope, localStorageService, schedulesService, environmentService) {
    var _this = this;
    page.call(this, $scope, environmentService);

    /**
     * Dias da semana
     * 
     * @type {Array.<string>}
     */
    $scope.DAYS = ["SEG", "TER", "QUA", "QUI", "SEX", "SAB"];
    
    /**
     * Dias da semana da pós-graduação
     * 
     * @type {Array.<number>}
     */
    $scope.DAYS_GRA = [2, 3, 4, 5, 6, 7];
    
    /**
     * Dia selecionado
     * 
     * @type {string}
     */
    $scope.selectedDay = $scope.DAYS[0];
    
    /**
     * Dia selecionado da pós-graduação
     * 
     * @type {number}
     */
    $scope.selectedDayGra = $scope.DAYS_GRA[0];
    
    /**
     * Nível do curso atual
     * 
     * @type {string}
     */
    $scope.studentCourseLevel = null;

    /**
     * Atualiza a tela
     * 
     * @memberof schedulesController
     * @function
     */
    $scope.refresh = function () {
        _this.refresh();
    };

    /**
     * Método chamado quando a busca retornar com erro
     * 
     * @memberof schedulesController
     * @function
     */
    $scope.handleError = function (errorResult, dialog) {
        _this.handleError(errorResult, dialog);
    };

    /**
     * Esconde a view de progresso
     * 
     * @memberof schedulesController
     * @function
     */
    $scope.hideLoading = function () {
        _this.hideLoading();
    };

    /**
     * Inicializa a tela
     *
     * @memberof schedulesController
     * @function
     */
    $scope.init = function () {
        _this.showLoading();
        $scope.pageTitle = "Quadro de Horários";
        $scope.studentCourseLevel = localStorageService.get('studentCourseLevel');
    };

    /**
     * Verifica se um dia da semana está selecionado
     *
     * @memberof schedulesController
     * @function
     * 
     * @param {string} day Dia @see{DAYS}
     *
     * @return {boolean} True se estiver selecionado, false caso contrário
     */
    $scope.isDaySelected = function (day) {
        return $scope.selectedDay == day;
    };

    /**
     * Seleciona um dia da semana
     *
     * @memberof schedulesController
     * @function
     * 
     * @param {string} day Dia @see{DAYS}
     */
    $scope.selectDay = function (day) {
        var days = {"SEG": 2, "TER": 3, "QUA": 4, "QUI": 5, "SEX": 6, "SAB": 7};

        $scope.selectedDay = day;
        $scope.selectedDayGra = days[day];
    };
}

schedulesController.prototype = Object.create(page.prototype);