"use strict";

/**
 * Controlador da tela de configuração
 *
 * @class
 * @name configurationController
 * 
 * 
 * @param {Object} $rootScope Escopo principal
 * @param {Object} $timeout Serviço de timeout
 * @param {Object} $scope Escopo
 * @param {Object} $log Log
 * @param {environmentService} environmentService Serviço de informações do ambiente
 * @param {pagesService} pagesService Serviço de gerenciamento do menu e páginas
 * @param {configurationService} configurationService Serviço que busca os cursos do usuário para configurar a aplicação
 * @param {localStorageService} localStorageService Serviço de armazenamento local
 * @param {Object} $analytics Serviço para coletar dados analíticos
 */
function configurationController(
		$rootScope, $timeout, $scope, $log, environmentService, pagesService,
		configurationService, localStorageService, $analytics) {
    
	var STUDENT_NAME_KEY = "studentName";
	var STUDENT_DOCUMENT_KEY = "studentDocument";
	var STUDENT_NUMBER_KEY = "studentNumber";
	var STUDENT_COURSE_LEVEL_KEY = "studentCourseLevel";
	var STUDENT_COURSE_CHOSEN_KEY =" studentCourseChosen";
	var USER_LOGIN_KEY = "userLogin";
	var STUDENT_COURSE_NAME_KEY = "studentCourseName";
	var ALL_COURSES_KEY = "allCourses";
	var COURSES_DICTIONARY = "CoursesDictionary";
	var COURSES_UNDERGRADUATE_KEY = "coursesUndergraduate";
	var COURSES_GRADUATION_KEY = "coursesGraduation";
	var INITIAL_PAGE_GRADUATION_KEY = "initialPageGraduation";
	var INITIAL_PAGE_UNDERGRADUATE_KEY = "initialPageUndergraduate";
	var GRADUATION = "POSGRADUACAO";
	var UNDERGRADUATE = "GRADUACAO";
	
	var _this = this;
    page.call(this, $scope, environmentService);

    /**
     * Inicializa a tela
     *
     * @memberof configurationController
     * @function
     */
    $scope.init = function () {
        $scope.pageTitle = "CONFIGURAÇÕES";
        _this.refresh();
        $scope.loadData();
        $scope.isActivated;
    };

    /**
     * Carrega os dados para inicializar a tela
     * 
     * @memberof configurationController
     * @function
     */
    $scope.loadData = function () {
        $scope.user = {
            name: localStorageService.get(STUDENT_NAME_KEY),
            userId: localStorageService.get(STUDENT_DOCUMENT_KEY),
            login: localStorageService.get(USER_LOGIN_KEY)
        };
        
        $scope.currentCourse = localStorageService.get(STUDENT_COURSE_NAME_KEY);
        $scope.currentLogin = localStorageService.get(STUDENT_NUMBER_KEY);

        $scope.courseContext = null;
        $scope.initialCourseInfo = {};
        $scope.initalSelectedPage;
        $scope.courses = {};
        $scope.coursePages = [];
        $scope.coursesUndergraduate;
        $scope.coursesGraduation;
        $scope.getPages();
        $scope.loadInitialPageInfo(localStorageService.get(STUDENT_COURSE_LEVEL_KEY));
    };

    /**
     * Trata o resultado da busca dos dados no backend quando for feita com sucesso
     *
     * @memberof configurationController
     * @private
     * @function handleRequest
     * @method success
     */
    var handleRequest = function () {
        function treatError(thisData) {
            if (thisData.data.errors.length > 0) {
                $scope.errors = true;
                $scope.errorMessage = {
                    "message": thisData.data.errors[0].message
                };
                
                $timeout(function () {
                    _this.handleError($scope.errorMessage, $scope.dialog);
                }, 100);
                
                return $scope.errors;
            }
            return 0;
        }

        function success(thisData) {
            if (thisData == null || thisData.data == null || thisData.data.errors == null && thisData.data.data == null) {
                $log.error("O servidor não retornou dados válidos ao buscar pelos cursos do aluno.");
                _this.hideLoading();
                $scope.dialog.error("Não foi possível buscar os seus cursos neste momento.");
                return;
            }

            if (treatError(thisData) != 0) {
                return;
            }

            $scope.courses = thisData.data.data;
            localStorageService.set(ALL_COURSES_KEY, thisData.data.data);
        }

        return {
            success: function (result) {
                success(result);
                $scope.loadInitialCourseInfo();
                _this.hideLoading();
            }
        };
    }();

    /**
     * Busca dos os cursos do estudante
     * 
     * @memberof configurationController
     * @function
     */
    $scope.getAllCoursesFromStudentDoc = function () {
        _this.showLoading();
        
        $scope.allCourses = configurationService
        	.getAllCourses(localStorageService.get(STUDENT_DOCUMENT_KEY))
	        .then(handleRequest.success, function (result) {
	            _this.handleError(result, $scope.dialog);
	        });
    };

    /**
     * Altera o curso
     *
     * @memberof configurationController
     * @function
     */
    $scope.changeCourse = function () {
        var thisCourse = {};

        for (var i = $scope.courses.length - 1; i >= 0; i--) {
            if ($scope.courses[i].aluno_matricula == $scope.courseInfo) {
            	
                thisCourse = $scope.courses[i];
                $scope.currentCourse = $scope.courses[i].curso_nome;
                $scope.currentLogin = $scope.courses[i].aluno_matricula;
                $scope.currentLevel = $scope.courses[i].nivel_de_ensino;
                $scope.currentStudentId = $scope.courses[i].aluno_id;
                
                localStorageService.set(COURSES_DICTIONARY, $scope.courses[i]);
                break;
            }
        }

        $analytics.eventTrack("Curso Nível", {category: "CONFIGURATION", label: $scope.currentLevel});
        $analytics.eventTrack("Curso", {category: "CONFIGURATION", label: $scope.currentCourse});

        localStorageService.set(STUDENT_COURSE_NAME_KEY, $scope.currentCourse);
        localStorageService.set(STUDENT_NUMBER_KEY, $scope.currentLogin);
        localStorageService.set(STUDENT_COURSE_CHOSEN_KEY, $scope.currentStudentId);
        localStorageService.set(STUDENT_COURSE_LEVEL_KEY, $scope.currentLevel);

        $scope.getPages();
        $scope.loadInitialPageInfo(localStorageService.get(STUDENT_COURSE_LEVEL_KEY));
    };

    /**
     * Carrega as páginas conforme o nível do curso atualmente selecionado
     *
     * @memberof configurationController
     * @function
     */
    $scope.getPages = function () {            
        $scope.coursePages = pagesService.getPagesForConfiguration();
        console.log("getPages: " + JSON.stringify($scope.coursePages));
    };

    /**
     * Carrega o curso inicial
     *
     * @memberof configurationController
     * @function
     */
    $scope.loadInitialCourseInfo = function () {
        if ($scope.courses != null) {
            for (var i = 0, size = $scope.courses.length; i < size; i++) {
                if ($scope.courses[i].aluno_matricula == localStorageService.get(STUDENT_NUMBER_KEY) 
                		|| $scope.courses[i].aluno_id == localStorageService.get(STUDENT_COURSE_CHOSEN_KEY)) {
                    $scope.initialCourseInfo = $scope.courses[i];
                    $scope.courseInfo = $scope.courses[i].aluno_matricula;
                }
            }
        }
    };

    /**
     * Carrega a página inicial
     *
     * @memberof configurationController
     * @function
     * 
     * @param {string} studentCourseLevel Nível do curso
     */
    $scope.loadInitialPageInfo = function (studentCourseLevel) {
    	if (studentCourseLevel.toUpperCase() == GRADUATION ) {
    		$scope.initialSelectedPage = localStorageService.get(INITIAL_PAGE_GRADUATION_KEY);
    	} else {
    		$scope.initialSelectedPage = localStorageService.get(INITIAL_PAGE_UNDERGRADUATE_KEY);
    	}
    };

    /**
     * Define a página inicial
     *
     * @memberof configurationController
     * @function
     */
    $scope.setInitialPage = function () {
    	
    	$analytics.eventTrack("Página Inicial", {category: "CONFIGURATION", label: $scope.initialPageInfo});
    	
        switch (localStorageService.get(STUDENT_COURSE_LEVEL_KEY).toUpperCase()) {
            case GRADUATION:
                localStorageService.set(INITIAL_PAGE_GRADUATION_KEY, $scope.initialPageInfo);
                break;
            default:
                localStorageService.set(INITIAL_PAGE_UNDERGRADUATE_KEY, $scope.initialPageInfo);
                break;
        }
    };
}

configurationController.prototype = Object.create(page.prototype);
