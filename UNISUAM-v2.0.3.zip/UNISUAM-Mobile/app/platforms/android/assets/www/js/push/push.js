"use strict";

(function() {
	/**
	 * Módulo de push
	 */
	var pushModule = angular.module("PushModule", [ "config", "logger" ]);

	/**
	 * Método executado quando o módulo é criado
	 */	
	pushModule.run(["$rootScope", "localStorageService", "environmentService", 
	                function($rootScope, localStorageService, environmentService) {
		
		var IS_REGISTERED_FOR_PUSH = "isRegisteredForPush";
		var TOKEN = "token";
		
		/**
		 * Mensagem da notificação
		 * 
		 * @type {string}
		 */
		$rootScope.notificationMessage;
		
		/**
		 * Imagem da notificação
		 * 
		 * @type {string}
		 */
		$rootScope.notificationImage = null;

		/**
		 * Indica se o dispositivo está registrado para push
		 * 
		 * @return {boolean} True se o dispositivo está registrado para push, false caso contrário
		 */
		$rootScope.isRegisteredForPush = function() {
			var isRegisteredForPush = localStorageService.get(IS_REGISTERED_FOR_PUSH);
			if (isRegisteredForPush == null) {
				isRegisteredForPush = false;
				localStorageService.set(IS_REGISTERED_FOR_PUSH, isRegisteredForPush);
			}
			return isRegisteredForPush;
		};

		/**
		 * Define que o dispositivo está registrado para puch
		 * 
		 * @param {boolean} Indica se deve ser registrado para push ou não
		 */
		$rootScope.setIsRegisteredForPush = function(_isRegisteredForPush) {
			var isRegisteredForPush = _isRegisteredForPush != null ? _isRegisteredForPush : $rootScope.isRegisteredForPush();
			localStorageService.set(IS_REGISTERED_FOR_PUSH, isRegisteredForPush);
		};

		/**
		 * Retorna o token do dispositivo
		 * 
		 * @returns {string} Token
		 */
		$rootScope.token = function() {
			var token = localStorageService.get(TOKEN);
			if (token == null) {
				token = "";
				localStorageService.set(TOKEN, token);
			}
			return token;
		};

		/**
		 * Token do dispositivo
		 * 
		 * @param {string} _token Token 
		 */
		$rootScope.setToken = function(_token) {
			var token = _token != null ? _token : $rootScope.token();
			localStorageService.set(TOKEN, token);
		};

		/**
		 * Identificador do usuário
		 * 
		 * @returns {string} Documento do estudante (CPF)
		 */
		$rootScope.userId = function() {
			return localStorageService.get("studentDocument");
		};
		
		/**
		 * Método chamado quando uma notificação for recebida
		 */
		$rootScope.$watch(function() {
			return $rootScope.notificationMessage;
		}, function(_data) {
			if (_data && (_data != null || _data.length != 0)) {
				$rootScope.$broadcast("NotificationReceived", {
					message : _data,
					imageSource : $rootScope.notificationImage
				});
			}
		});
	}]);
})();
