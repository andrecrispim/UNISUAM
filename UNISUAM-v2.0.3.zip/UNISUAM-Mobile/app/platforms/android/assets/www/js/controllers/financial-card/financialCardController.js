"use strict";

/**
 * Controlador da tela de finanças da pós-graduação
 *
 * @class
 * @name financialCardController
 * 
 * @param {Object} $scope Escopo
 * @param {Object} $log Log
 * @param {environmentService} environmentService Serviço de informações do ambiente
 * @param {localStorageService} localStorageService Serviço de armazenamento local
 * @param {financialCardService} financialCardService Serviço para busca de finanças
 */
function financialCardController(
		$scope, $log, environmentService, localStorageService, financialCardService) {
    var _this = this;
    page.call(this, $scope, environmentService);
    
    /**
     * Nível do curso atual
     * 
     * @type {string}
     */
    $scope.studentCourseLevel = null;

    /**
     * Trata o evento disparado quando um repeater termina
     *
     * @param {Object} ngRepeatFinishedEvent Evento
     */
    $scope.$on('ngRepeatFinished', function (ngRepeatFinishedEvent) {
        _this.refresh();
    });

    /**
     * Inicializa a tela
     *
     * @memberof reportCardController
     * @function
     */
    $scope.init = function () {
        _this.showLoading();
        $scope.pageTitle = "Ficha Financeira";

        $scope.studentCourseLevel = localStorageService.get('studentCourseLevel');
    };

    /**
     * Atualiza a tela
     * 
     * @memberof financialCardController
     * @function
     */
    $scope.refresh = function () {
        _this.refresh();
    };

    /**
     * Método chamado quando a busca retornar com erro
     * 
     * @memberof financialCardController
     * @function
     */
    $scope.handleError = function (errorResult, dialog) {
        _this.handleError(errorResult, dialog);
    };

    /**
     * Esconde a view de progresso
     * 
     * @memberof financialCardController
     * @function
     */
    $scope.hideLoading = function () {
        _this.hideLoading();
    };
    
    /**
     * Abre uma url
     *
     * @memberof financialCardController
     * @function
     * 
     * @param {string} url Url/PDF to open
     */
    $scope.openExternal = function (url) {
        window.open(url, '_system', 'location=no');
    };
}

financialCardController.prototype = Object.create(page.prototype);