"use strict";

/**
 * Controlador da tela de boletim da pós-graduação
 *
 * @class
 * @name graduationReportCardController
 * 
 * @param {Object} $scope Escopo
 * @param {reportCardService} reportCardService Serviço para busca do boletim
 */
function graduationReportCardController($scope, reportCardService) {
    
	/**
     * Inicializa a tela
     *
     * @memberof graduationReportCardController
     * @function
     */
    $scope.init = function () {
        reportCardService.getReportCard().then(handleSuccess, function (result) {
            $scope.handleError(result, $scope.dialog);
        });
    };

    /**
     * Método chamado quando a busca do boletim for finalizada com sucesso
     *
     * @memberof graduationReportCardController
     * @private
     * @function
     * @method success
     * 
     * @param {Object} result Resultado, inclui a configuração da requisição, cabeçalho e status
     */
    function handleSuccess(result) {
        $scope.reportCard = result.data.data != null ? result.data.data.boletim : null;
        $scope.messages.length = 0;

        if (result.data.errors != null && result.data.errors.length > 0) {
            for (var i = 0, len = result.data.errors.length; i < len; i++) {
                $scope.messages.push(result.data.errors[i].message);
            }
        } else if ($scope.reportCard == null) {
            $scope.messages.push("Não há dados cadastrados até o momento.");
        } else {
            $scope.disciplinesHeader = $scope.reportCard.columns;
            $scope.disciplinesBody = $scope.reportCard.data;
        }

        $scope.hideLoading();
    }
}