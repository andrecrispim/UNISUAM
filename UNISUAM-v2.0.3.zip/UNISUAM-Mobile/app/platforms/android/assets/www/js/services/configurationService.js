/**
 * Serviço que busca os cursos do usuário para configurar a aplicação
 *
 * @class
 * @name configurationService
 * 
 * @param {Object} $http Serviço HTTP
 * @param {CONFIG} CONFIG Configuração
 */
app.service('configurationService', ['$http', 'CONFIG', function ($http, CONFIG) {
	
    /**
     * Busca a lista de cursos do usuário
     *
     * @memberof configurationService
     * @function
     * 
     * @param {string} studentDoc Documento do usuário (CPF)
     * 
     * @return {Object} Promessa com resultado da requisição
     */
    this.getAllCourses = function (studentDoc) {
        var url = CONFIG.SERVICES.COURSELIST + "/" + studentDoc;
        return $http.get(url);
    };
}]);