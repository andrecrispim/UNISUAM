'use strict';

/**
 * Aplicação da UNISUAM
 */
var app = angular.module('unisuamApp', [ 'ngResource', 'ngRoute', 'LocalStorageModule', 
        'foundation.offcanvas', 'config', 'PushModule', 'ngSanitize', 'angular-data.DSCacheFactory', 
        'logger', 'angulartics', 'angulartics.google.analytics', 'angulartics.debug' ]);

// configura o armazenamento local
app.config([ 'localStorageServiceProvider', function(localStorageServiceProvider) {
	localStorageServiceProvider.setPrefix('unisuamData');
}]);

// configuração requida pelo Windows Phone para que a navegação seja feita com sucesso
app.config(['$compileProvider', function($compileProvider) {
	$compileProvider.aHrefSanitizationWhitelist(/^\s*(https?|ftp|mailto|file|ghttps?|ms-appx|x-wmapp0):/);
}]);

// configura o angulartics
app.config([ '$analyticsProvider', function($analyticsProvider) {
	$analyticsProvider.virtualPageviews(true);
	$analyticsProvider.firstPageview(true);
}]);

// configura o roteamento
app.config([ '$routeProvider', function($routeProvider) {
	$routeProvider.when('/', {
		templateUrl : 'views/login.html',
		controller : 'loginController'
	}).when('/choose-course', {
		templateUrl : 'views/choose-course.html',
		controller : 'chooseCourseController'
	}).when('/report-card', {
		templateUrl : 'views/report-card.html',
		controller : 'reportCardController'
	}).when('/exams', {
		templateUrl : 'views/exams.html',
		controller : 'examsController'
	}).when('/configuration', {
		templateUrl : 'views/configuration.html',
		controller : 'configurationController'
	}).when('/news', {
		templateUrl : 'views/news.html',
		controller : 'newsController'
	}).when('/schedules', {
		templateUrl : 'views/schedules.html',
		controller : 'schedulesController'
	}).when('/financial-card', {
		templateUrl : 'views/financial-card.html',
		controller : 'financialCardController'
	}).when('/indications', {
		templateUrl : 'views/indications.html',
		controller : 'indicationsController'
	}).when('/logout', {
		templateUrl : 'views/logout.html',
		controller : 'logoutController'
	}).otherwise({
		redirectTo : '/'
	});
}]);

// configura o provedor do serviço de requisição HTTP adicionando um interceptador
app.config([ '$httpProvider', function($httpProvider) {
	$httpProvider.interceptors.push('httpInterceptor');
}]);

// configura o cache
app.config([ 'DSCacheFactoryProvider', 'CONFIG', function(DSCacheFactoryProvider, CONFIG) {
	DSCacheFactoryProvider.setCacheDefaults({
		maxAge : CONFIG.CACHE.MAX_AGE, // Items added to this cache expire after MAX_AGE (milliseconds).
		cacheFlushInterval : CONFIG.CACHE.FLUSH_INTERVAL, // This cache will clear itself every interval.
		storageMode : 'localStorage', // This cache will sync itself with `localStorage`
		deleteOnExpire : 'aggressive' // Items will be deleted from this cache right when they expire.
	});
}]);

// configura o serviço de requisição HTTP adicionando o cache
app.run([ '$http', 'DSCacheFactory', function($http, DSCacheFactory) {
	$http.defaults.cache = DSCacheFactory('defaultCache');
}]);

// adiciona eventos para tratar a navegação e registrar o dispositivo para push
app.run(['$rootScope', '$timeout', 'pushRegistration', 'localStorageService', 'environmentService', '$log', 'CONFIG',
         function($rootScope, $timeout, pushRegistration, localStorageService, environmentService, $log, CONFIG) {
	
	// exit APP on android, when back button return to login from choose-course
	$rootScope.$on("$routeChangeStart", function(event, next, current) {
		if (current != null && current.$$route != null && next != null && next.$$route != null
				&& navigator != null && navigator.app != null) {
			
			$log.debug("from: " + current.$$route.originalPath + " to: " + next.$$route.originalPath);

			if (current.$$route.originalPath != "/logout") {
				// exit the application if the is an user logged and next
				// page is login page or  choose-course page
				if (current.$$route.originalPath != "/" && current.$$route.originalPath != ""
						&& (next.$$route.originalPath == "/" || next.$$route.originalPath == ""
							|| next.$$route.originalPath == "/choose-course")) {
					navigator.app.exitApp();
				}

				// exit the application if there is no user logged and next page isn't login page.
				if (next.$$route.originalPath != "/" && next.$$route.originalPath != ""
						&& localStorageService.get("studentDocument") == null) {
					navigator.app.exitApp();
				}
			}
		}
	});
	
	// configuração do google analytics
  	ga('create', CONFIG.ANALYTICS.UA, {
		  'storage': 'none',
		  'clientId': 'ff8fa1f9-f22c-4f28-bc6a-d34ef9b50e5e'
	});		  
  	ga('set', 'checkProtocolTask', null);
	ga('set', 'checkStorageTask', null);

	var isDeviceReady = false;

	$rootScope.isDeviceReady = function() {
		return isDeviceReady;
	};

	document.addEventListener("deviceready", function() {
		$log.info("Device Ready!");
		
		// libera a splashscreen
		setTimeout(function() {
	        navigator.splashscreen.hide();
	    }, 2000);
				
		isDeviceReady = true;
		
		// não alterar a fonte conforme a configuração do dispositivo
		if(window.MobileAccessibility){
		    window.MobileAccessibility.usePreferredTextZoom(false);
		}
		
		// esconde a barra de status no windows phone e no IOS
		if (environmentService.isWindowPhone()) {
			StatusBar.hide();
			
			// corrigir o tamanho do body no windows phone 8
	        $timeout(function () {
	        	$(document.body).height($(document).height());
	        }, 150);		  	
		} else if (environmentService.isIOS()) {
		    StatusBar.hide();
	    }
		
		var logged = localStorageService.get("logged");
				
		// as notificações deve ser ativadas se houver um usuário logado
		if (logged) {
			pushRegistration.register();
		} else {
			var token = $rootScope.token();

			if (token != "" || token != null) {
				$rootScope.setToken("");
			}
		}
	});
}]);
