/**
 * Serviço responsável por buscar as Notícias no servidor remoto
 *
 * @class
 * @name newsService
 * 
 * @param {Object} $http Serviço HTTP
 * @param {localStorageService} localStorageService Serviço de armazenamento local
 * @param {CONFIG} CONFIG Configuração
 */
app.service('newsService', ['$http', 'localStorageService', 'CONFIG',
                            function ($http, localStorageService, CONFIG) {
    var UNDERGRADUATE = 'GRADUACAO';

    /**
     * Busca as notícias
     *
     * @memberof newsService
     * @function
     * 
     * @return {Object} Promessa com os dados da requisição
     */
    this.getNews = function () {
        var studentCourseLevel = localStorageService.get('studentCourseLevel');
        var url = null;
        
        var config = {
            params: {
                token: CONFIG.UNISUAM_APP_TOKEN
            }
        };

        if (studentCourseLevel == UNDERGRADUATE) {
            url = CONFIG.SERVICES.UNDERGRADUATE.NEWS;            
        } else {
            url = CONFIG.SERVICES.GRADUATION.NEWS;
        }
        
        url = url + "/" + localStorageService.get('studentCourseChosen');

        return $http.get(url, config);
    };
}]);