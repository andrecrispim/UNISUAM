"use strict";

/**
 * Controller who controls the schedules screen
 *
 * @class
 * @param {Object} $scope Scope
 * @param {schedulesService} schedulesService Service that queries the remote server for schedules
 */
function undergraduateSchedulesController($scope, schedulesService) {
	
	var errors = null;
	
	/**
	 * Dados do quadro de horário
	 * 
	 * @type {Array.<Object>}
	 */
    $scope.schedules = null;
    
	/**
	 * Dados filtrados do quadro de horário
	 * 
	 * @type {Array.<Object>}
	 */
    $scope.filteredSchedules = null;
    
    /**
     * Indica se um quadro de horário foi encontrado
     * 
     * @type {boolean}
     */
    $scope.hasSchedules = false;
    
    /**
     * Trata o evento disparado quando um repeater termina
     *
     * @param {Object} ngRepeatFinishedEvent Evento
     */
    $scope.$on('ngRepeatFinished', function (ngRepeatFinishedEvent) {
        $scope.refresh();
    });

    /**
     * Trata a troca do dia selecionado da pós-graduação
     */
    $scope.$parent.$watch("selectedDayGra", filterSchedulesByDay);

    /**
     * Inicializa a tela
     *
     * @memberof undergraduateSchedulesController
     * @function
     */
    $scope.init = function () {
        schedulesService.getSchedules().then(handleSuccess, function (result) {
            $scope.handleError(result, $scope.dialog);
        });
    };

    /**
     * Método chamado quando a busca do quadro de horário for finalizada com sucesso
     *
     * @memberof undergraduateSchedulesController
     * @private
     * @function
     * @method success
     * 
     * @param {Object} result Resultado, inclui a configuração da requisição, cabeçalho e status
     */
    function handleSuccess(result) {

        angular.forEach(result.data.data.quadro_horario, function (value, key) {
            $scope.value = value;
        });

        $scope.schedules = $scope.value;
        $scope.horarios = result.data.data.horarios;
        $scope.messages.length = 0;

        if (result.data.errors.length <= 1) {
            errors = result.data.errors;
            
            if (result.data.message) {
            	$scope.messages.push(result.data.message);
            }
        }

        filterSchedulesByDay($scope.selectedDayGra);

        $scope.hideLoading();
    }

    /**
     * Filtra o quadro de horário pelo dia da semana selecionado
     *
     * @private
     * @function
     * 
     * @param {string} day Dia da semana selecionado @see{DAYS}
     */
    function filterSchedulesByDay(day) {
    	
    	// limpa as mensagens se o resultado não possuir errors
        if (errors == null || errors.length == 0) {
            $scope.messages.length = 0;
        }

        if ($scope.schedules != null) {

            $scope.filteredSchedules = $scope.schedules.filter(function (schedule) {
                return schedule.codigo_diasemana == day;
            });

            $scope.hasSchedules = $scope.filteredSchedules.length > 0;
        } else {
            $scope.filteredSchedules = null;
            $scope.hasSchedules = false;
        }

        if (!$scope.hasSchedules && $scope.messages.length == 0) {
            $scope.messages.push("Não há horários cadastrados até o momento para este dia.");
        }
    }
}