"use strict";

/**
 * Controlador do menu
 *
 * @class
 * @name menuController
 * 
 * @param {Object} $scope Escopo
 * @param {Object} $log Log
 * @param {environmentService} environmentService Serviço de informações do ambiente
 * @param {pagesService} pagesService Serviço para busca do menu e dados das páginas
 */
function menuController($scope, $log, pagesService) {
    var _this = this;
    
    
    $scope.menu = null;

    /**
     * Inicializa a tela
     *
     * @memberof menuController
     * @function
     */
    $scope.init = function () {
        showLoading();
        $scope.getData();
    };

    /**
     * Busca os dados no backend e trata o resultado
     *
     * @memberof menuController
     * @function
     */
    $scope.getData = function () {
    	if (pagesService.hasMenu()) {
    		$scope.menu = pagesService.getMenuPages();
    	} else {
    		pagesService.getMenu().then(function(result) {
    			$scope.menu = result;
    		});
    	}
    };
        
    /**
     * Exibe a view de progresso
     *
     * @memberof menuController
     * @protected
     * @function
     */
    function showLoading() {
    	document.getElementById("loading-modal").style.display = "block";
    };

    /**
     * Esconde a view de progresso
     * 
     * @memberof menuController
     * @protected
     * @function
     */
    function hideLoading() {
    	document.getElementById("loading-modal").style.display = "none";
    };
}