/**
 * Página
 *
 * @class
 * @name page
 */
function page($scope, environmentService){
  var _this = this;

  _this.bodyHeight = 'auto';
  _this.showScroll = false;
  _this.environmentService = environmentService;

  /**
   * Mensagens a serem exibidas
   * 
   * @type {Array.<string>}
   */
  $scope.messages = [];
  
  /**
   * Título da página
   * 
   * @type {string}
   */
  $scope.pageTitle = " ";

  /**
   * Altura do body
   * 
   * @returns {number} Altura
   */
  $scope.getBodyHeight = function () {
    return _this.bodyHeight;
  };

  /**
   * Indica se a janela deve conter uma scroll
   * 
   * @returns {boolean} True se a scroll deve ser exibida, false caso contrário
   */
  $scope.mustShowScroll = function() {
    return _this.showScroll;
  };
}

/**
 * Método que atualiza a página e calcula a altura da mesma
 *
 * @memberof page
 * @protected
 * @function
 */
page.prototype.refresh = function() {
    this.bodyHeight = 'auto';
  	this.showScroll = false;

  	var headerHeight = $(".page-header").height();
	var bodyWrapHeight = $(".page-body-wrap").height();
	var contentHeight = bodyWrapHeight - headerHeight;
	
	this.bodyHeight = contentHeight + 'px';
};


/**
 * Exibe uma mensagem de erro ocorrido numa requisição
 *
 * @memberof page
 * @protected
 * @function
 * 
 * @param {Object} errorResult Informações do erro ocorrido
 * @param {dialog} dialog Diálogo para exibição da mensagem
 */
 page.prototype.handleError = function(errorResult, dialog) {
  if (errorResult.status == -1) {
      dialog.warning(errorResult.message);
  } else {
      dialog.error(errorResult.message);
  }

  this.hideLoading();
};

/**
 * Exibe a view de progresso
 *
 * @memberof page
 * @protected
 * @function
 */
page.prototype.showLoading = function () {
  document.getElementById("loading-modal").style.display = "block";
};

/**
 * Esconde a view de progresso
 * 
 * @memberof page
 * @protected
 * @function
 */
page.prototype.hideLoading = function () {
  document.getElementById("loading-modal").style.display = "none";
};