"use strict";

/**
 * Controlador da tela de indicações
 *
 * @class
 * @name indicationsController
 * 
 * @param {Object} $scope Scope
 * @param {Object} $timeout Serviço de timeout
 * @param {indicationsService} indicationsService Serviço para busca e criação de indicações
 * @param {environmentService} environmentService Serviço de informações do ambiente
 */
function indicationsController($scope, $timeout, indicationsService, environmentService) {
	var _this = this;
    page.call(this, $scope, environmentService);
        
    /**
     * Indica se retornou com errors
     * 
     * @type {boolean}
     */
    $scope.hasError = false;
    
    /**
     * Indica se encontrou indicações
     * 
     * @type {boolean}
     */
    $scope.hasIndications = false;
        
    /**
     * Descrição
     * 
     * @type {string}
     */
    $scope.description = null;
    
    /**
     * Cabeçalho da lista de indicações
     * 
     * @type {Array.<string>}
     */
    $scope.indicationsHeaders = [];
    
    /**
     * Indicações
     * 
     * @type {Array.<Object>}
     */
    $scope.indications = [];       
       
    /**
     * Indica se está no período que permitir indicar
     * 
     * @type {boolean}
     */
    $scope.isOnIndicationPeriod = true;
    
    /**
     * Nova indicação
     * 
     * @type {Object}
     */
    $scope.indication = {
		name: null,
		cpf : null,
		email: null
    }
    
    /**
     * Indica se o formulário já foi submetido
     * 
     * @type {boolean}
     */
    $scope.submitted = false;
        
    /**
     * Indicação selecionada na lista
     */
    $scope.selectedIndication = null;

    /**
     * Trata o evento disparado quando um repeater termina
     *
     * @param {Object} ngRepeatFinishedEvent Evento
     */
    $scope.$on('ngRepeatFinished', function (ngRepeatFinishedEvent) {
        _this.refresh();
    });
    
    /**
     * Inicializa a tela
     *
     * @memberof indicationsController
     * @function
     */
    $scope.init = function () {
        _this.showLoading();
        $scope.pageTitle = "Indicações";

        indicationsService.getIndications().then(handleGetIndicationsSuccess, function (result) {
            _this.handleError(result, $scope.dialog);
        });
    };
    
    /**
     * Muda de Tab
     * 
     * @memberof indicationsController
     * @function 
     * 
     * @param {string} currentTab Tab atualmente selecionada
     */
    $scope.toggleTab = function(currentTab) {
    	var activeClass = "active";
    	var secondaryClass = "secondary";
    	
    	if (currentTab === "tabIndicate" ) {
    	    $('#tabIndications').addClass(secondaryClass);
    	    $('#tabIndicate').removeClass(secondaryClass);
    	    
    	    $('#contentIndications').removeClass(activeClass);    	    
    	    $('#contentIndicate').addClass(activeClass);
    	} else {
    		$('#tabIndicate').addClass(secondaryClass);     	    
    	    $('#tabIndications').removeClass(secondaryClass);
    	    
    	    $('#contentIndicate').removeClass(activeClass);
    	    $('#contentIndications').addClass(activeClass);
    	}
    }
    
    /**
     * Abre ou fecha os detalhes de uma indicação
     *
     * @memberof indicationsController
     * @function
     * 
     * @param {number} index Índice da indicação
     */
    $scope.showDetails = function (index) {    	
        $scope.selectedIndication = $scope.indications[index];
        $('#detailsModal').foundation('reveal', 'open');
    };
    
    $scope.dismissDetails = function (index) {    	
    	$('#detailsModal').foundation('reveal', 'close');
    	$scope.selectedIndication = null;
    }
    
    /**
     * Indica se há erros nos dados informados pelo usuário
     * 
     * @memberof indicationsController
     * @function 
     * 
     * @param {string} field Campo
     * @param {boolean} submitting Indica se está submetendo o formulário ou não
     * 
     * @returns {boolean} True se existir erros no campo, falso caso contrário
     */
    $scope.hasError = function (field, submitting) {
    	if (submitting) {
    		return $scope.indicationForm[field].$invalid;
    	}
    	    	    	
        return (!$scope.indicationForm[field].$dirty && $scope.submitted && $scope.indicationForm[field].$invalid);
    };
    
    /**
     * Envia uma nova indicação
     * 
     * @memberof indicationsController
     * @function 
     */
    $scope.sendIndication = function() {
    	$scope.submitted = true;
    	
    	$scope.hasError("nameField", true);
    	$scope.hasError("emailField", true);
    	$scope.hasError("cpfField", true);
    	
    	$scope.indicationForm.$setPristine();
    	
    	if ($scope.indicationForm.$valid) {
    		_this.showLoading();
    		
            indicationsService.register($scope.indication).then(handleSendIndicationSuccess, function (result) {
                _this.handleError(result, $scope.dialog);
            });
    	}
    }
    
    /**
     * Busca um cabeçalho pelo seu nome
     *
     * @private
     * @function
     * 
     * @param {string} name Nome
     */
    function getHeaderByName(name) {
    	var i = 0;
    	var header = null;
    	
    	while (i < $scope.indicationsHeaders.length && header === null) {
    		var currentHeader = $scope.indicationsHeaders[i];
    		
    		if (currentHeader.value.campo === name) {
    			header = currentHeader;
    		}    		
    			
    		i++;
    	}    	
    	
    	return header;
    }
    
    /**
     * Método chamado quando uma nova indicação for enviada com sucesso
     *
     * @memberof indicationsController
     * @private
     * @function
     * @method success
     * 
     * @param {Object} result Resultado, inclui a configuração da requisição, cabeçalho e status
     */
    function handleSendIndicationSuccess(result) {
    	
    	$scope.submitted = false;
        $scope.messages.length = 0;
        
        if (result.data.errors !== null && result.data.errors.length > 0) {
            for (var i = 0, len = result.data.errors.length; i < len; i++) {
                $scope.messages.push(result.data.errors[i].message);
            }
        } else {
        	// reloads
            indicationsService.getIndications().then(function(result) {
            	handleGetIndicationsSuccess(result);
            	$scope.dialog.success("Indicação enviada com sucesso");
            }, function (result) {
                _this.handleError(result, $scope.dialog);
            });
        }
    }
    
    /**
     * Método chamado quando a busca de indicações terminar com sucesso
     *
     * @memberof indicationsController
     * @private
     * @function
     * @method success
     * 
     * @param {Object} result Resultado, inclui a configuração da requisição, cabeçalho e status
     */
    function handleGetIndicationsSuccess(result) {
    	$scope.indicationsHeaders = [];
        $scope.indications = []; 
        $scope.hasIndications = result.data.data !== null;
        $scope.messages.length = 0;
        
        if (result.data.errors !== null && result.data.errors.length > 0) {
            for (var i = 0, len = result.data.errors.length; i < len; i++) {
                $scope.messages.push(result.data.errors[i].message);
            }
        } else if ($scope.hasIndications) {
        	var data = result.data.data;
        	$scope.description = data.texto;
        	            
            Object.keys(data.titulos).forEach(function (key) {
            	var title = data.titulos[key];
            	var displayRules = title.mostrarMobile;
            	
            	title.smallUp = displayRules["visible-sm"];
            	title.mediumUp = !title.smallUp && displayRules["visible-md"];
            	title.largeUp = !title.smallUp && !title.mediumUp && displayRules["visible-lg"];
            	
            	$scope.indicationsHeaders.push({key: key, value: title});
            });
            
            for (var i = 0, len = data.indicacoes.length; i < len; i++) {
            	var indication = data.indicacoes[i];
            	var values = []; 	
            	
            	Object.keys(indication).forEach(function (key) {
            		var column = indication[key];
            		var header = getHeaderByName(column.campo)
            		
            		column.smallUp = header.value.smallUp;
            		column.mediumUp = header.value.mediumUp;
            		column.largeUp = header.value.largeUp;
            		            		
            		values.push({key: header.key, value: column });
                });
            	
            	$scope.indications.push({ indication: values });
            }
            
        }
    	
    	_this.hideLoading();
    }
}

indicationsController.prototype = Object.create(page.prototype);