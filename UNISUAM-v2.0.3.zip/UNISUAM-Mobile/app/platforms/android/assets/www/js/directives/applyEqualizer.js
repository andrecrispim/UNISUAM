/**
 * Diretiva que aplica um equalizador de altura
 * 
 * @class
 * @name applyEqualizer
 * 
 * @param {Object} $timeout Serviço de timeout
 */
app.directive('applyEqualizer', ['$timeout', function($timeout) {
    return {
      restrict: 'A',
      scope: {
        onVisible: '&'
      },
      link: function(scope, element, attrs, controller){
        scope.$watch(function() {return element.attr('class'); }, function(newValue){
          if (element.hasClass('active')) {
            $timeout(function() {
              Foundation.libs.equalizer.init();
            }, 50);
          }
        });
      }
    };
}]);