/**
 * Serviço responsável por buscar a Ficha Financeira no servidor remoto
 *
 * @class
 * @name financialCardService
 * 
 * @param {Object} $http Serviço HTTP
 * @param {localStorageService} localStorageService Serviço de armazenamento local
 * @param {CONFIG} CONFIG Configuração
 */
app.service('financialCardService', ['$http', 'localStorageService', 'CONFIG',
                                     function ($http, localStorageService, CONFIG) {
    var UNDERGRADUATE = 'GRADUACAO';
	
	/**
     * Busca a ficha financeira
     *
     * @memberof financialCardService
     * @function
     * 
     * @return {Object} Promessa com resultado da requisição
     */
    this.getFinancialData = function () {
    	var studentCourseLevel = localStorageService.get('studentCourseLevel');
    	var studentId = localStorageService.get("studentCourseChosen");
    	var url = null;
    	
        var config = {
            params: {
                token: CONFIG.UNISUAM_APP_TOKEN
            }
        };
    	
    	if (studentCourseLevel == UNDERGRADUATE) {
    		url = CONFIG.SERVICES.UNDERGRADUATE.FINANCES;
    	} else {
            url = CONFIG.SERVICES.GRADUATION.FINANCES;
    	}
    	
    	url = url + '/' + studentId;
    	
    	return $http.get(url, config);
    };
}]);