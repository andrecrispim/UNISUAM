"use strict";

/**
 * Controlador da tela de logout
 * 
 * @class
 * @name logoutController
 * 
 * @param {Object} $rootScope Escopo principal
 * @param {Object} $scope Escopo
 * @param {Object} $location Serviço para obtenção e troca de local (páginas)
 * @param {Object} $log Log
 * @param {localStorageService} localStorageService Serviço de armazenamento local
 * @param {pushRegistration} Classe responsável por registrar e desregistrar o dispositivo para recebimento de notificações
 * @param {DSCacheFactory} DSCacheFactory Serviço de cache
 */
function logoutController($rootScope, $scope, $location, $log, localStorageService, pushRegistration, DSCacheFactory) {

	/**
	 * Cancela o logout
	 * 
	 * @memberof logoutController
	 * @function
	 */
    $scope.cancel = function () {
        history.go(-1);
    };

    /**
     * Desloga, limpando os dados locais, cache e removendo o registro para recebimento do push
     * 
     * @memberof logoutController
     * @function
     */
    $scope.logout = function () {
        $log.info("Efetuando o logout da aplicação, usuário: " + localStorageService.get('studentCourseChosen'));

        document.getElementById("loading-modal").style.display = "block";

        if ($rootScope.isRegisteredForPush() == true || $rootScope.isRegisteredForPush() == "true") {
            var token = $rootScope.token();
            pushRegistration.unregister(token);
        }

        localStorageService.clearAll();
        DSCacheFactory.clearAll();

        $location.path("/");
    };
}