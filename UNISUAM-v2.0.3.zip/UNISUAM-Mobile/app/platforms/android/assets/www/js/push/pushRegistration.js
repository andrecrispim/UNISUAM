
var pushModule = angular.module("PushModule");

/**
 * Classe responsável por registrar e desregistrar o dispositivo para recebimento de notificações
 * 
 * @class
 * @name pushRegistration
 * 
 * @param {Object} $rootScope Escopo principal
 * @param {Object} $log Log
 * @param {CONFIG} CONFIG Configuração
 * @param {environmentService} environmentService Serviço de informações do ambiente
 * @param {pushAPI} pushAPI Push API
 */
pushModule.service("pushRegistration", ["$rootScope", "$log", "CONFIG", "environmentService", "pushAPI",  
                                        function($rootScope, $log, CONFIG, environmentService, pushAPI) {
	
	var DEACTIVING_ERROR_MESSAGE = "Não foi possível desativar as notificações neste momento.";
	var ACTIVING_ERROR_MESSAGE = "Não foi possível ativar as notificações neste momento.";
	var push = null;
	
	/**
	 * Registra o dispositivo
	 * 
	 * @memberof pushRegistration
     * @function
	 */
	this.register = function() {
		// teste apenas feito para manter a página testável em browsers
		if (typeof PushNotification !== 'undefined') {
			$log.info("Registering device for push.");
			
			push = PushNotification.init({
			    android: {
			        senderID: CONFIG.PUSH_NOTIFICATION.SENDER_ID
			    },
			    ios: {
			        alert: 'true',
			        badge: 'true',
			        sound: 'true'
			    },
			    wp8: {
			    	channelName: 'UnisuamChannel'
			    }
			});
			
			push.on('registration', function(data) { onRegistration(data); });				
			push.on('notification', function(data) { onNotification(data); });		
			push.on('error', function(err) { $log.error(err); });
		}
	}
	
	
	/**
	 * Método executado quando o token para envio de notificações for recebido 
	 * 
	 * @memberof pushRegistration
     * @function
     * 
     * @param {string} data Token do dispositivo
	 */
     function onRegistration(data) {    	 
    	$log.info("Device registered: " + JSON.stringify(data));    	 
				
		var deviceType = environmentService.getDeviceType();
		var token = $rootScope.token();

		if (token != data.registrationId) {
			$log.info("sending token to backend: " + data.registrationId);
			
			$rootScope.setToken(data.registrationId);

			if (token == "") {
				var pushInfo = {
					token : data.registrationId,
					userId : $rootScope.userId(),
					type : deviceType
				};

				pushAPI.register(pushInfo);
				
			} else {
				var pushInfo = {
					oldToken : token,
					newToken : data.registrationId,
					userId : $rootScope.userId()
				};

				pushAPI.update(pushInfo);
			}
		}
	};
	
	function onNotification(data) {
		$log.info("onNotification: " + JSON.stringify(data));
		
		var deviceType = environmentService.getDeviceType();
		var message;
		var imageUrl;
		
		switch (deviceType) {
		case 1: // Android
			// if this flag is set, this notification happened while we were in the foreground.
			if (data.foreground) {
				navigator.notification.vibrate();
			}
			
			message = data.message;
			
			if (data.payload != null && data.payload.custom != null && data.payload.custom.length > 0) {
				imageUrl = data.payload.custom[0].icon_url;
			}
			
			break;
		case 2: // iOS
			if (data.alert) {
				navigator.notification.vibrate();
				message = data.alert;
				
				if (data.icon_url != null) {
					imageUrl = data.icon_url;
				}
			}			
			break;
		case 3: // Windows Phone
			if (data.content != null && data.content["wp:Text2"] != null) {
				message = data.content["wp:Text2"];
				
				if (data.content["wp:Data"] != null 
						&& data.content["wp:Data"].custom != null 
						&& data.content["wp:Data"].custom.length > 0) {
					imageUrl = data.content["wp:Data"].custom[0].icon_url;
				}
			}
			break;
		}
		
		$rootScope.$apply(function() {
			$rootScope.notificationMessage = message;
			$rootScope.notificationImage = imageUrl;
		});
	}
	
	/**
	 * Desregistra o dispositivo
	 * 
	 * @memberof pushRegistration
     * @function
     * 
	 * @param {string} token Token do dispositivo
	 */
	this.unregister = function(token) {
		$log.info("unregister: " + token);
		
		// armazena o token quando estiver desregistrando no logout
		if (token != null) {
			$rootScope.tempToken = token;
		}
		
		push.unregister(this.unregisterSuccessHandler, this.unregisterErrorHandler);
	}
	
	/**
	 * Método executado quando ocorrer erro ao desregistrar o dispositivo 
	 * 
	 * @memberof pushRegistration
     * @function
     * 
     * @param {string} data Dados do erro
	 */
	this.unregisterErrorHandler = function(data) {
		$log.info("unregisterErrorHandler: " + JSON.stringify(data));
		
		$timeout(function() {
			$rootScope.$broadcast("ErrorReceived", { message : DEACTIVING_ERROR_MESSAGE });
		}, 50);

		$log.error(data);
	};	

	/**
	 * Método executado quando o dispositivo for desregistrado com sucesso 
	 * 
	 * @memberof pushRegistration
     * @function
	 */
	this.unregisterSuccessHandler = function() {
		$log.info("unregisterSuccessHandler: ");
		
		var token = $rootScope.token();

		// in case of logoff
		if (token == "") {
			token = $rootScope.tempToken;
		}

		var pushInfo = {
			token : token
		};

		pushAPI.unregister(pushInfo);
	};
	
	/**
	 * Método executado quando ocorrer erro ao registrar o dispositivo 
	 * 
	 * @memberof pushRegistration
     * @function
     * 
     * @param {string} data Dados do erro
	 */
	function registerErrorHandler(data) {
		$log.info("registerErrorHandler: " + JSON.stringify(data));
		
		$timeout(function() {
			$rootScope.$broadcast("ErrorReceived", { message : ACTIVING_ERROR_MESSAGE });
		}, 50);

		$log.error(data);
	};
}]);