/**
 * Serviço responsável por buscar o Boletim no servidor remoto
 *
 * @class
 * @name reportCardService
 * 
 * @param {Object} $http Serviço HTTP
 * @param {localStorageService} localStorageService Serviço de armazenamento local
 * @param {CONFIG} CONFIG Configuração
 */
app.service('reportCardService', ['$http', 'localStorageService', 'CONFIG',
                                  function ($http, localStorageService, CONFIG) {
    var UNDERGRADUATE = 'GRADUACAO';

    /**
     * Busca o boletim do curso atual
     *
     * @memberof reportCardService
     * @function
     * 
     * @return {Object} Promessa com resultado da requisição
     */
    this.getReportCard = function () {
        var studentCourseLevel = localStorageService.get('studentCourseLevel');
        var url = null;
        
        var config = {
            params: {
                token: CONFIG.UNISUAM_APP_TOKEN
            }
        };

        if (studentCourseLevel == UNDERGRADUATE) {
            url = CONFIG.SERVICES.UNDERGRADUATE.REPORT_CARD;
            url = url + "?aluno_id=" + localStorageService.get('studentCourseChosen');
        } else {
            url = CONFIG.SERVICES.GRADUATION.REPORT_CARD;
            url = url + "/" + localStorageService.get('studentCourseChosen');
        }

        return $http.get(url, config);
    };
}]);