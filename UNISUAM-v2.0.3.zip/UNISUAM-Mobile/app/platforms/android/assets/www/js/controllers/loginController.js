"use strict";

/**
 * Controlador da tela de login
 * 
 * @class
 * @name loginController
 * 
 * @param {Object} $scope Escopo
 * @param {Object} $location Serviço para obtenção e troca de local (páginas)
 * @param {Object} $log Log
 * @param {loginService} loginService Serviço que efetua o login do usuário
 * @param {localStorageService} localStorageService Serviço de armazenamento local
 * @param {environmentService} environmentService Serviço de informações do ambiente
 * @param {Object} pushRegistration Classe responsável por registrar e desregistrar o dispositivo para recebimento de notificações
 * @param {Object} $analytics Serviço para coletar dados analíticos
 * @param {pagesService} pagesService Serviço de gerenciamento do menu e páginas
 */
function loginController($scope, $location, $log, loginService, localStorageService, 
		environmentService, pushRegistration, $analytics, pagesService) {

    /**
     * Inicializa a tela
     *
     * @memberof loginController
     * @function
     */
    $scope.init = function () {

        if (localStorageService.get("logged")) {        	
            redirect();
            
        } else {
            $scope.userLogin = null;
            $scope.userPass = null;
            $scope.disabledSubmit = true;
            $scope.coursesUndergraduate = [];
            $scope.coursesGraduation = [];
            document.getElementById("loading-modal").style.display = "none";
        }
    };

    /**
     * Método que valida os dados informados para habilitar ou desabilitar o botão de login
     *
     * @memberof loginController
     * @function
     */
    $scope.validateSubmit = function () {
        $scope.disabledSubmit = true;

        if ($scope.userLogin && $scope.userPass && $scope.userLogin.length >= 8 && $scope.userPass.length >= 3) {
            $scope.disabledSubmit = false;
        }
    };

    /**
     * Salva os dados do estudante
     *
     * @memberof loginController
     * @function
     */
    $scope.storeStudentData = function () {
        localStorageService.set('studentDocument', $scope.resultLogin.data.aluno_cpf);
        localStorageService.set('studentName', $scope.resultLogin.data.aluno_nome);
    };

    /**
     * Mapeia um curso pelo número da matrícula
     * 
     * @memberof loginController
     * @private
     * @function
     * 
     * @param {Object} Informações do curso
     */
     function mapCourseByRegistration(_courseInfo) {
        var courses = localStorageService.get("CoursesDictionary");

        if (courses == null) {
            courses = {};
        }

        var key = _courseInfo.aluno_matricula;
        courses[key] = _courseInfo;
        localStorageService.set("CoursesDictionary", courses);
    };

    /**
     * Método que salva os dados do curso
     *
     * @memberof loginController
     * @function
     */
    $scope.storeCoursesData = function () {
        $log.info("Armazenando cursos, " + JSON.stringify($scope.resultLogin.data.detalhes));

        for (var i = 0; i < $scope.resultLogin.data.detalhes.length; i++) {
            mapCourseByRegistration($scope.resultLogin.data.detalhes[i]);

            switch ($scope.resultLogin.data.detalhes[i].nivel_de_ensino) {
                case "POSGRADUACAO":
                    $scope.coursesGraduation.push($scope.resultLogin.data.detalhes[i]);
                    localStorageService.set('coursesGraduation', $scope.coursesGraduation);
                    break;
                default:
                    $scope.coursesUndergraduate.push($scope.resultLogin.data.detalhes[i]);
                    localStorageService.set('coursesUndergraduate', $scope.coursesUndergraduate);
                    break;
            }
        }
    };

    /**
     * Redireciona para a tela inicial conforme configurações salvas pelo usuário
     * 
     * @memberof loginController
     * @private
     * @function
     * 
     * @param {Object} Informações do curso inicial
     */
	function redirectByInitialConfigData(_initialCourseInfo) {
		var initialPageNameGraduation = localStorageService.get("initialPageGraduation");
    	var initialPageNameUndergraduate = localStorageService.get("initialPageUndergraduate");
    	var hasInitialPage = initialPageNameGraduation || initialPageNameUndergraduate;
    	var path = "/news";
               
    	if (hasInitialPage) {
    		var page = null;
	        	
	    	if (localStorageService.get("studentCourseLevel") == "GRADUACAO") {           	
            	page = pagesService.getPageByName(initialPageNameUndergraduate);            	
            } else if (localStorageService.get("studentCourseLevel") == "POSGRADUACAO") {
                page = pagesService.getPageByName(initialPageNameGraduation);
            }
	    		    		    	
	    	if (page == null) {
	    		page = pagesService.getPagesForConfiguration()[0];
	    	}
	    	
	    	path = page.path;
    	}
    	 
    	$location.path(path);
    };

    /**
     * Indica se o aluno possui curso de graduação
     * 
     * @memberof loginController
     * @private
     * @function
     * 
     * @return {boolean} True se possuir curso de graduação, false caso contrário
     */
    function hasUndergraduate() {
        var coursesUndergraduate = localStorageService.get("coursesUndergraduate");

        return coursesUndergraduate != null && coursesUndergraduate.length >= 1;
    };

    /**
     * Indica se o aluno possui curso de pós-graduação
     * 
     * @memberof loginController
     * @private
     * @function
     * 
     * @return {boolean} True se possuir curso de pós-graduação, false caso contrário
     */
    function hasGraduation() {
        var coursesGraduation = localStorageService.get("coursesGraduation");

        return coursesGraduation != null && coursesGraduation.length >= 1;
    };

    /**
     * Método responsável por redirecionar para a página correta conforme os dados de login
     *
     * @memberof loginController
     * @private
     * @function
     */
    function redirect() {
        var initialCourseInfo = localStorageService.get("studentCourseChosen");

        if (initialCourseInfo != null) {
            redirectByInitialConfigData(initialCourseInfo);
        } else {       	
        	// se possuir cursos dos dois níveis e se o usuário logou com o CPF
        	// redireciona para a tela de seleção de nivel
        	if (hasUndergraduate() && hasGraduation()
        			&& localStorageService.get('userLogin') == localStorageService.get('studentDocument')) {
                $location.path("/choose-course");
                return;
        	}
        	
        	var course;
        	var courseLevel;
        	
            if (hasUndergraduate() && hasGraduation()) {
                var courses = localStorageService.get("CoursesDictionary");
                course = courses[localStorageService.get('userLogin')];                
            } else {  
                if (hasUndergraduate()) {            
                    course = localStorageService.get("coursesUndergraduate")[0];                    
                } else {
                    course = localStorageService.get("coursesGraduation")[0];
                }
            }    
                                    
            $analytics.eventTrack("Curso Nível", {category: "CONFIGURATION", label: course.nivel_de_ensino});
            $analytics.eventTrack("Curso", {category: "CONFIGURATION", label: course.curso_nome});
            
            localStorageService.set('studentCourseLevel', course.nivel_de_ensino);
            localStorageService.set('studentCourseChosen', course.aluno_id);
            localStorageService.set('studentCourseName', course.curso_nome);
            localStorageService.set('studentNumber', course.aluno_matricula);

            $location.path("/news");
        }
    };

    /**
     * Método que efetua o login do usuário
     *
     * @memberof loginController
     * @function
     * 
     * @todo: Single Responsability
     */
    $scope.doLogin = function () {
        if (!$scope.disabledSubmit) {
            document.getElementById("loading-modal").style.display = "block";
            loginService.undergraduateVerifyLogin($scope.userLogin.toUpperCase(), $scope.userPass).then(handleSuccess, handleError);
        }
    };

    /**
     * Método chamado quando o resultado do login for recebido com sucesso
     *
     * @memberof loginController
     * @private
     * @function
     * @method success
     * 
     * @param {Object} result Resultado, inclui a configuração da requisição, cabeçalho e status
     */
    function handleSuccess(result) {
        $scope.resultLogin = result.data;

        if ($scope.resultLogin != null && ($scope.resultLogin.errors != null || $scope.resultLogin.data != null)) {
            if ($scope.resultLogin.errors != null && $scope.resultLogin.errors.length > 0) {
                if (!environmentService.isAndroid2()) {
                    $scope.dialog.warning($scope.resultLogin.errors[0].message);
                } else {
                    navigator.notification.alert($scope.resultLogin.errors[0].message, null, "Alerta!");
                }

                document.getElementById("loading-modal").style.display = "none";
            } else {
                localStorageService.set('logged', true);
                localStorageService.set('userLogin', $scope.userLogin.toUpperCase());
                localStorageService.set('userPass', $scope.userPass);
                $scope.storeStudentData();
                $scope.storeCoursesData();           
                
                $analytics.eventTrack('Login', {category: 'LOGIN', label: localStorageService.get('studentDocument')});

                pushRegistration.register();

                redirect();
            }
        } else {
            $log.error("O servidor não retornou dados válidos.");
            document.getElementById("loading-modal").style.display = "none";
            $scope.dialog.error("Não foi possível efetuar o login, tente novamente mais tarde.");
        }
    }

    /**
     * Exibe uma mensagem caso ocorra erro no login
     *
     * @memberof loginController
     * @private
     * @function
     * 
     * @param {Object} errorResult Dados do erro ocorrido
     */
    function handleError(errorResult) {
        if (errorResult.status == -1) {
            $scope.dialog.warning(errorResult.message);
        } else {
            $scope.dialog.error(errorResult.message);
        }

        document.getElementById("loading-modal").style.display = "none";
    }
}