"use strict";

/**
 * Controlador da tela do calendário de provas
 *
 * @class
 * @name examsController
 * 
 * @param {Object} $scope Scope
 * @param {examsService} examsService Serviço para busca do calendário de prvoa
 * @param {environmentService} environmentService Serviço de informações do ambiente
 */
function examsController($scope, examsService, environmentService) {
    var _this = this;
    page.call(this, $scope, environmentService);

    /**
     * Calendário de provas
     * 
     * @type {Array.<Object>}
     */
    $scope.exams = null;
    
    /**
     * Indica se retornou com erros
     * 
     * @type {boolean}
     */
    $scope.hasError = false;
    
    /**
     * Indica se encontrou um calendário de provas
     * 
     * @type {boolean}
     */
    $scope.hasExams = false;
    
    /**
     * Mensagem a ser exibida
     * 
     * @type {string}
     */
    $scope.message = null;

    /**
     * Trata o evento disparado quando um repeater termina
     *
     * @param {Object} ngRepeatFinishedEvent Evento
     */
    $scope.$on('ngRepeatFinished', function (ngRepeatFinishedEvent) {
        _this.refresh();
    });

    /**
     * Inicializa a tela
     *
     * @memberof examsController
     * @function
     */
    $scope.init = function () {
        _this.showLoading();
        $scope.pageTitle = "Calendário de Provas";

        examsService.getExams().then(handleSuccess, function (result) {
            _this.handleError(result, $scope.dialog);
        });
    };

    /**
     * Método chamado quando a busca de exames terminar com sucesso
     *
     * @memberof examsController
     * @private
     * @function
     * @success
     * 
     * @param {Object} result Resultado, inclui a configuração da requisição, cabeçalho e status
     */
    function handleSuccess(result) {

        $scope.data = [];
        var dataprova = [];
        var col_nome = [];
        var col_dataprova = [];
        var i = 0;

        angular.forEach(result.data.data.dados_disciplinas, function (dados, key) {
            angular.forEach(dados, function (value, key) {

                dataprova = [];
                if (value['dataprova']) {
                    dataprova = value['dataprova'].replace('{', '').replace('}', '').split(',');
                }

                col_nome = [];
                if (value['col_nome']) {
                    col_nome = value['col_nome'].replace('{', '').replace('}', '').split(',');
                }

                col_dataprova = [];
                if (value['col_dataprova']) {
                    col_dataprova = value['col_dataprova'].replace('{', '').replace('}', '').split(',');
                }

                $scope.dataprova = [];
                angular.forEach(dataprova, function (value_dataprova, key_dataprova) {
                    $scope.dataprova.push({dataAvaliacao: value_dataprova});
                });

                $scope.col_nome = [];
                angular.forEach(col_dataprova, function (value_col_dataprova, key_col_dataprova) {
                    if (value_col_dataprova == 't') {
                        $scope.col_nome.push({avaliacao: col_nome[key_col_dataprova]});
                    }

                });

                $scope.data.push({
                    disciplina_nome: value['disciplina'],
                    datas: $scope.dataprova,
                    avaliacoes: $scope.col_nome
                });

                i++;
            });
        });

        $scope.value = $scope.data;

        $scope.exams = $scope.value;
        $scope.hasExams = $scope.exams != null && $scope.exams.length > 0;
        $scope.hasError = result.data.erro;

        if ($scope.hasError) {
            $scope.message = result.data.message;
        } else if (!$scope.hasExams) {
            $scope.message = "Não há provas cadastradas até o momento.";
        }

        _this.hideLoading();
    }
}

examsController.prototype = Object.create(page.prototype);