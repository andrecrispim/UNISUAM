"use strict";

/**
 * Controlador da tela de finanças da pós-graduação
 *
 * @class
 * @name graduationFinancialCardController
 * 
 * @param {Object} $scope Escopo
 * @param {Object} $log Log
 * @param {financialCardService} financialCardService Serviço para busca de finanças
 */
function graduationFinancialCardController($scope, $log, financialCardService) {

	/**
     * Inicializa a tela
     *
     * @memberof graduationFinancialCardController
     * @function
     */
    $scope.init = function () {
    	 financialCardService.getFinancialData().then(handleRequest.success, function (result) {
    		 $scope.handleError(result, $scope.dialog);
         });
    };

    /**
     * Trata o resultado da busca dos dados no backend quando for feita com sucesso
     *
     * @memberof graduationFinancialCardController
     * @private
     * @function
     * @method success
     */
    var handleRequest = function () {
        function treatError(thisData) {
            if (thisData.data.errors.length > 0) {
                $scope.errors = true;
                $scope.errorMessage = {
                    "message": thisData.data.errors[0].message
                };

                $scope.handleError($scope.errorMessage, $scope.dialog);
                return $scope.errors;
            }
        }

        function success(thisData) {
            if (thisData == null || thisData.data == null || thisData.data.errors == null && thisData.data.data == null) {
                $log.error("O servidor não retornou dados válidos ao buscar por ficha financeira.");
                $scope.hideLoading();
                $scope.dialog.error("Não foi possível buscar a ficha financeira, tente novamente.");
                return;
            }

            if (!treatError(thisData)) {
                $scope.errors = thisData.data.errors;
                $scope.result = thisData.data.data[0];
            }
        }

        return {
            success: function (result) {
                success(result);
                $scope.hideLoading();
            }
        };
    }();
}